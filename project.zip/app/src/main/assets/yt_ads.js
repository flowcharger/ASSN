/* ASSN ad blocker for YouTube: strips ad data from player replies, skips ads that still start, hides ad boxes. */
(function () {
  if (window.__assnYt) return;
  window.__assnYt = true;

  var KEYS = ["adPlacements", "playerAds", "adSlots", "adBreakHeartbeatParams"];
  function strip(o) {
    try {
      if (o && typeof o === "object") {
        for (var i = 0; i < KEYS.length; i++) {
          if (KEYS[i] in o) delete o[KEYS[i]];
        }
        if (o.playerResponse) strip(o.playerResponse);
      }
    } catch (e) {}
    return o;
  }

  try {
    var parse = JSON.parse;
    JSON.parse = function () { return strip(parse.apply(this, arguments)); };
    if (window.Response && Response.prototype.json) {
      var rjson = Response.prototype.json;
      Response.prototype.json = function () { return rjson.apply(this, arguments).then(strip); };
    }
  } catch (e) {}

  try {
    var css = document.createElement("style");
    css.textContent =
      "#masthead-ad,#player-ads,#panels ytd-ads-engagement-panel-content-renderer,ytd-ad-slot-renderer," +
      "ytd-in-feed-ad-layout-renderer,ytd-banner-promo-renderer,ytd-statement-banner-renderer," +
      "ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,ytd-promoted-video-renderer," +
      "ytm-promoted-sparkles-web-renderer,ytm-companion-slot,ytm-promoted-video-renderer," +
      ".ytp-ad-overlay-container,.ytp-ad-module,.video-ads,.ytd-merch-shelf-renderer," +
      "ytd-rich-item-renderer:has(ytd-ad-slot-renderer){display:none!important}";
    (document.head || document.documentElement).appendChild(css);
  } catch (e) {}

  var inAd = false, savedMuted = false;
  function tick() {
    var p = document.getElementById("movie_player");
    var v = (p && p.querySelector("video")) || document.querySelector("video");
    var ad = !!(p && p.classList.contains("ad-showing"));
    if (ad && v) {
      if (!inAd) { inAd = true; savedMuted = v.muted; }
      v.muted = true;
      try { v.playbackRate = 16; } catch (e) {}
      if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.2) {
        try { v.currentTime = v.duration - 0.1; } catch (e) {}
      }
    } else if (inAd && v) {
      inAd = false;
      v.muted = savedMuted;
      try { v.playbackRate = 1; } catch (e) {}
    }
    var skip = document.querySelector(
      ".ytp-skip-ad-button,.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-ad-skip-button-container button");
    if (skip) skip.click();
    var close = document.querySelector(".ytp-ad-overlay-close-button");
    if (close) close.click();
  }
  setInterval(tick, 250);
})();

(function () {
  var tabs = [];
  var activeId = 0;
  var nextId = 1;
  var showingOverview = false;
  var isClearing = false;
  var currentPage = "browser";
  var historyItems = [];
  var bookmarks = [];
  var closedTabs = [];
  var downloads = [];
  var toastTimer = null;
  var native = window.AssnNative || null;
  var lastCount = -1;
  var ZOOM_MIN = 30;
  var ZOOM_MAX = 130;
  var ZOOM_STEP = 10;
  var SOUND_ON =
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z"></path>' +
    '<path d="M16.5 8.5a5 5 0 0 1 0 7"></path><path d="M19 6a8.5 8.5 0 0 1 0 12"></path></svg>';
  var SOUND_OFF =
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z"></path>' +
    '<path d="m17 9 5 6M22 9l-5 6"></path></svg>';

  var tabsBox = document.getElementById("tabs");
  var newTab = document.getElementById("newTab");
  var counter = document.getElementById("counter");
  var homePage = document.getElementById("homePage");
  var result = document.getElementById("result");
  var resultUrl = document.getElementById("resultUrl");
  var resultTitle = document.getElementById("resultTitle");
  var resultText = document.getElementById("resultText");
  var overview = document.getElementById("overview");
  var cards = document.getElementById("cards");
  var emptyState = document.getElementById("emptyState");
  var overviewPlus = document.getElementById("overviewPlus");
  var overviewClear = document.getElementById("overviewClear");
  var overviewBack = document.getElementById("overviewBack");
  var emptyNewTab = document.getElementById("emptyNewTab");
  var mintSweep = document.getElementById("mintSweep");
  var addressForm = document.getElementById("addressForm");
  var addressInput = document.getElementById("addressInput");
  var searchForm = document.getElementById("searchForm");
  var searchInput = searchForm.querySelector("input");
  var reloadButton = document.getElementById("reloadButton");
  var back = document.getElementById("backButton");
  var forward = document.getElementById("forwardButton");
  var menuButton = document.getElementById("menuButton");
  var menuPanel = document.getElementById("menuPanel");
  var toolView = document.getElementById("toolView");
  var toolTitle = document.getElementById("toolTitle");
  var toolContent = document.getElementById("toolContent");
  var toolBack = document.getElementById("toolBack");
  var toast = document.getElementById("toast");
  var zoomOut = document.getElementById("zoomOut");
  var zoomIn = document.getElementById("zoomIn");
  var zoomValue = document.getElementById("zoomValue");

  function activeTab() {
    var i;
    for (i = 0; i < tabs.length; i++) {
      if (tabs[i].id === activeId) return tabs[i];
    }
    return null;
  }

  function escapeText(value) {
    return String(value).replace(/[&<>"']/g, function (char) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
      }[char];
    });
  }

  function bump(element, className) {
    element.classList.remove(className);
    void element.offsetWidth;
    element.classList.add(className);
  }

  function setAddress(value) {
    addressInput.value = value;
    if (document.activeElement !== addressInput) {
      try {
        addressInput.setSelectionRange(0, 0);
      } catch (error) {}
    }
  }

  function updateCounter() {
    counter.textContent = tabs.length;
    if (lastCount !== tabs.length) {
      lastCount = tabs.length;
      bump(counter, "bump");
    }
  }

  function shorten(text) {
    return text.length > 24 ? text.slice(0, 24) + "\u2026" : text;
  }

  function isWebAddress(value) {
    return /^https?:\/\//i.test(value || "");
  }

  function resolveInput(text) {
    if (isWebAddress(text)) return text;

    var domain = /^([a-z0-9-]+\.)+[a-z]{2,}(:\d+)?([\/?#].*)?$/i;
    var local = /^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?([\/?#].*)?$/i;

    if (!/\s/.test(text)) {
      if (local.test(text)) return "http://" + text;
      if (domain.test(text)) return "https://" + text;
    }

    return "https://html.duckduckgo.com/html/?q=" + encodeURIComponent(text);
  }

  /* The ASSN search page is a plain results page that the app restyles. */
  function isSearchAddress(url) {
    try {
      var parsed = new URL(url);
      var host = parsed.hostname.toLowerCase();
      return (
        host === "html.duckduckgo.com" ||
        (host === "duckduckgo.com" && parsed.pathname.indexOf("/html") === 0)
      );
    } catch (error) {
      return false;
    }
  }

  function searchQuery(url, title) {
    var query = "";
    try {
      query = new URL(url).searchParams.get("q") || "";
    } catch (error) {}
    if (!query && title) {
      query = String(title)
        .replace(/\s+at DuckDuckGo$/i, "")
        .replace(/\s+\u2013\s+ASSN$/, "");
    }
    return query;
  }

  /* Search pages show what was searched for, not the search engine's URL. */
  function displayAddress(url, title) {
    if (isSearchAddress(url)) return searchQuery(url, title) || "ASSN search";
    return url;
  }

  function syncNative() {
    if (!native) return;
    var tab = activeTab();
    var showWeb = !!(
      tab && tab.web && !tab.showHome && !showingOverview && currentPage === "browser"
    );
    var expanded = !showWeb || menuPanel.classList.contains("open");
    document.body.classList.toggle("web-mode", showWeb);
    try {
      native.setLayout(tab ? tab.id : 0, showWeb, expanded);
    } catch (error) {}
  }

  function saveState() {
    var payload = JSON.stringify({
      history: historyItems.slice(0, 100),
      bookmarks: bookmarks
    });
    try {
      if (native) native.setData("state", payload);
      else window.localStorage.setItem("assn_state", payload);
    } catch (error) {}
  }

  function cleanList(list) {
    var out = [];
    var i;
    if (!Array.isArray(list)) return out;
    for (i = 0; i < list.length; i++) {
      var item = list[i];
      if (item && typeof item.title === "string" && typeof item.address === "string") {
        out.push({ title: item.title, address: item.address });
      }
    }
    return out;
  }

  function loadState() {
    var raw = "";
    try {
      raw = native
        ? native.getData("state")
        : (window.localStorage.getItem("assn_state") || "");
    } catch (error) {}
    if (!raw) return;
    try {
      var data = JSON.parse(raw);
      historyItems = cleanList(data.history);
      bookmarks = cleanList(data.bookmarks);
    } catch (error) {}
  }

  function recordHistory(title, address) {
    if (historyItems.length > 0 && historyItems[0].address === address) {
      historyItems[0].title = title;
    } else {
      historyItems.unshift({ title: title, address: address });
      historyItems = historyItems.slice(0, 100);
    }
  }

  function makeTab(animate, privateMode) {
    if (isClearing) return;

    var tab = {
      id: nextId++,
      title: privateMode ? "Private tab" : "New tab",
      address: "",
      history: [""],
      position: 0,
      closing: false,
      isPrivate: !!privateMode,
      grouped: false,
      web: false,
      canBack: false,
      canForward: false,
      desktop: false,
      showHome: false,
      audible: false,
      muted: false,
      zoom: 100
    };

    tabs.push(tab);
    activeId = tab.id;
    showingOverview = false;
    currentPage = "browser";
    render();
    tabsBox.scrollLeft = tabsBox.scrollWidth;
    bump(newTab, "moving");

    if (animate) {
      var element = tabsBox.querySelector('[data-id="' + tab.id + '"]');
      if (element) element.classList.add("entering");
      setTimeout(function () {
        if (element) element.classList.remove("entering");
      }, 260);
    }
  }

  function renderTabs() {
    var i;
    var savedScroll = tabsBox.scrollLeft;
    tabsBox.innerHTML = "";

    for (i = 0; i < tabs.length; i++) {
      (function (tab) {
        var button = document.createElement("button");
        button.className =
          "tab" +
          (tab.id === activeId ? " active" : "") +
          (tab.grouped ? " grouped" : "");
        button.type = "button";
        button.setAttribute("data-id", tab.id);
        button.innerHTML =
          '<span class="mark">' + (tab.isPrivate ? "P" : "A") + "</span>" +
          '<span class="label">' + escapeText(tab.title) + "</span>" +
          (tab.audible || tab.muted
            ? '<span class="sound' + (tab.muted ? " off" : "") + '" role="button" aria-label="' +
              (tab.muted ? "Unmute tab" : "Mute tab") + '">' +
              (tab.muted ? SOUND_OFF : SOUND_ON) + "</span>"
            : "") +
          '<span class="close">×</span>';

        button.onclick = function (event) {
          if (event.target.closest && event.target.closest(".sound")) {
            toggleMute(tab.id, event);
            return;
          }
          if (event.target.className === "close") {
            closeTab(tab.id, event);
            return;
          }
          activeId = tab.id;
          showingOverview = false;
          render();
        };

        tabsBox.appendChild(button);
      })(tabs[i]);
    }

    tabsBox.appendChild(newTab);
    tabsBox.scrollLeft = savedScroll;
  }

  function toggleMute(id, event) {
    event.stopPropagation();
    var i;
    for (i = 0; i < tabs.length; i++) {
      if (tabs[i].id === id) {
        tabs[i].muted = !tabs[i].muted;
        if (native) {
          try {
            native.setMuted(id, tabs[i].muted);
          } catch (error) {}
        }
      }
    }
    renderTabs();
  }

  function renderCards() {
    var i;
    cards.innerHTML = "";

    for (i = 0; i < tabs.length; i++) {
      (function (tab) {
        var card = document.createElement("button");
        card.className =
          "card" +
          (tab.id === activeId ? " active" : "") +
          (tab.grouped ? " grouped" : "");
        card.type = "button";
        card.setAttribute("data-id", tab.id);
        card.innerHTML =
          '<span class="card-title">' +
          (tab.isPrivate ? "Private · " : "") +
          escapeText(tab.title) + "</span>" +
          '<span class="card-address">' +
          escapeText(displayAddress(tab.address, tab.title) || "ASSN homepage") +
          "</span>" +
          '<span class="card-close">×</span>';

        card.onclick = function (event) {
          if (event.target.className === "card-close") {
            closeTab(tab.id, event);
            return;
          }
          activeId = tab.id;
          showingOverview = false;
          render();
        };

        cards.appendChild(card);
      })(tabs[i]);
    }

    emptyState.hidden = tabs.length > 0;
    overviewClear.disabled = tabs.length === 0 || isClearing;
    overviewPlus.disabled = isClearing;
    overviewBack.disabled = isClearing;
    emptyNewTab.disabled = isClearing;
  }

  function getCardPositions() {
    var positions = {};
    var cardElements = cards.querySelectorAll(".card");
    var i;

    for (i = 0; i < cardElements.length; i++) {
      var card = cardElements[i];
      var rect = card.getBoundingClientRect();
      positions[card.getAttribute("data-id")] = {
        left: rect.left,
        top: rect.top
      };
    }

    return positions;
  }

  function animateCardReflow(oldPositions) {
    var cardElements = cards.querySelectorAll(".card");
    var i;

    for (i = 0; i < cardElements.length; i++) {
      var card = cardElements[i];
      var oldPosition = oldPositions[card.getAttribute("data-id")];
      if (!oldPosition) continue;

      var newRect = card.getBoundingClientRect();
      var x = oldPosition.left - newRect.left;
      var y = oldPosition.top - newRect.top;
      if (Math.abs(x) < 1 && Math.abs(y) < 1) continue;

      card.style.transition = "none";
      card.style.transform = "translate(" + x + "px," + y + "px)";
      void card.offsetWidth;

      (function (movingCard) {
        setTimeout(function () {
          movingCard.style.transition = "transform .24s ease";
          movingCard.style.transform = "translate(0,0)";

          setTimeout(function () {
            movingCard.style.transition = "";
            movingCard.style.transform = "";
          }, 270);
        }, 20);
      })(card);
    }
  }

  var desktopLabel = document.getElementById("desktopLabel");

  function updateMenuLabels() {
    var tab = activeTab();
    desktopLabel.textContent = tab && tab.desktop ? "Mobile mode" : "Desktop mode";
    var zoom = tab ? tab.zoom : 100;
    zoomValue.textContent = zoom + "%";
    zoomOut.disabled = zoom <= ZOOM_MIN;
    zoomIn.disabled = zoom >= ZOOM_MAX;
  }

  function changeZoom(value) {
    var tab = activeTab();
    if (!tab) return;
    var zoom = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, Math.round(value / ZOOM_STEP) * ZOOM_STEP));
    tab.zoom = zoom;
    if (native) {
      try {
        native.setZoom(tab.id, zoom);
      } catch (error) {}
    }
    updateMenuLabels();
  }

  function closeMenu() {
    menuPanel.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    syncNative();
  }

  function showToast(message) {
    if (native) {
      try {
        native.toast(message);
        return;
      } catch (error) {}
    }
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.classList.remove("show");
    }, 1900);
  }

  function openToolPage(pageName) {
    currentPage = pageName;
    showingOverview = false;
    closeMenu();
    render();
  }

  function makeToolRow(title, subtitle, action, index, trailing) {
    return (
      '<button class="tool-row" type="button" data-tool-action="' +
      action +
      '" data-index="' +
      index +
      '">' +
      '<span class="tool-row-main">' +
      '<span class="tool-row-title">' + escapeText(title) + "</span>" +
      '<span class="tool-row-subtitle">' + escapeText(subtitle) + "</span>" +
      "</span>" +
      "<span aria-hidden=\"true\">" + (trailing || "›") + "</span>" +
      "</button>"
    );
  }

  function renderToolPage() {
    var labels = {
      history: "History",
      downloads: "Downloads",
      bookmarks: "Bookmarks",
      recent: "Recent tabs",
      settings: "Settings"
    };
    toolTitle.textContent = labels[currentPage] || "ASSN Browser";

    var html = "";
    var i;

    if (currentPage === "history") {
      if (historyItems.length === 0) {
        html = '<div class="tool-empty">Your browsing history will appear here.</div>';
      } else {
        for (i = 0; i < historyItems.length; i++) {
          html += makeToolRow(
            historyItems[i].title,
            displayAddress(historyItems[i].address, historyItems[i].title),
            "visit-history",
            i
          );
        }
      }
    } else if (currentPage === "downloads") {
      html =
        '<form id="downloadForm" style="display:flex;gap:8px;margin-bottom:10px">' +
        '<input id="downloadUrl" type="url" required ' +
        'placeholder="Paste a file URL (https://…)" ' +
        'aria-label="File URL to download" ' +
        'style="flex:1;min-width:0;height:42px;padding:0 12px;border:1px solid #c8dfcb;border-radius:11px;background:#f8fcf8;color:#173121">' +
        '<button class="tool-action" type="submit" style="margin:0">Download</button>' +
        "</form>" +
        '<div class="tool-empty" style="padding:8px 4px 18px">' +
        "Paste a direct file link. Some websites block browser downloads; if that happens, the original link will open instead." +
        "</div>";

      if (downloads.length === 0) {
        html += '<div class="tool-empty">Your downloads will appear here.</div>';
      } else {
        for (i = 0; i < downloads.length; i++) {
          html +=
            '<div class="tool-row">' +
            '<span class="tool-row-main">' +
            '<span class="tool-row-title">' + escapeText(downloads[i].name) + "</span>" +
            '<span class="tool-row-subtitle">' + escapeText(downloads[i].address) + "</span>" +
            "</span>" +
            "<span>" + escapeText(downloads[i].status) + "</span>" +
            "</div>";
        }
      }
    } else if (currentPage === "bookmarks") {
      var tab = activeTab();
      if (tab && tab.address && !tab.isPrivate) {
        html +=
          '<button class="tool-action" type="button" data-tool-action="bookmark-current">' +
          "+ Bookmark this page" +
          "</button>";
      }

      if (bookmarks.length === 0) {
        html += '<div class="tool-empty">Saved pages will appear here.</div>';
      } else {
        for (i = 0; i < bookmarks.length; i++) {
          html +=
            '<div class="tool-row-wrap">' +
            makeToolRow(
              bookmarks[i].title,
              displayAddress(bookmarks[i].address, bookmarks[i].title),
              "visit-bookmark",
              i
            ) +
            '<button class="tool-remove" type="button" aria-label="Remove bookmark ' +
            escapeText(bookmarks[i].title) +
            '" data-tool-action="remove-bookmark" data-index="' +
            i +
            '">×</button></div>';
        }
      }
    } else if (currentPage === "recent") {
      if (closedTabs.length === 0) {
        html =
          '<div class="tool-empty">' +
          "Tabs you close will appear here.<br>Private tabs are not saved." +
          "</div>";
      } else {
        for (i = 0; i < closedTabs.length; i++) {
          html += makeToolRow(
            closedTabs[i].title,
            displayAddress(closedTabs[i].address, closedTabs[i].title) || "ASSN homepage",
            "restore-tab",
            i
          );
        }
      }
    } else if (currentPage === "settings") {
      html =
        '<div class="tool-row">' +
        '<span class="tool-row-main">' +
        '<span class="tool-row-title">Color theme</span>' +
        '<span class="tool-row-subtitle">Whitish green</span>' +
        "</span>" +
        '<span aria-hidden="true">✓</span>' +
        "</div>" +
        '<button class="tool-row" type="button" data-tool-action="clear-history">' +
        '<span class="tool-row-main">' +
        '<span class="tool-row-title">Clear browsing history</span>' +
        '<span class="tool-row-subtitle">Remove saved history from this preview</span>' +
        "</span>" +
        '<span aria-hidden="true">›</span>' +
        "</button>";
    }

    toolContent.innerHTML = html;
  }

  function openSavedAddress(item) {
    if (!activeTab()) makeTab(false);
    var tab = activeTab();
    if (!tab) return;

    if (native && !isWebAddress(item.address)) {
      showToast("This saved page can't be opened.");
      return;
    }

    tab.address = item.address;
    tab.title = item.title;
    tab.showHome = false;
    tab.history = tab.history.slice(0, tab.position + 1);
    tab.history.push(item.address);
    tab.position = tab.history.length - 1;
    currentPage = "browser";
    showingOverview = false;

    if (native) {
      tab.web = true;
      native.navigate(tab.id, item.address, !!tab.desktop);
    }

    render();
  }

  function startDownload(value) {
    var parsed;
    try {
      parsed = new URL(value);
    } catch (error) {
      showToast("Enter a valid file URL.");
      return;
    }

    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      showToast("Use an http or https file link.");
      return;
    }

    var fileName = parsed.pathname.split("/").pop() || "download";
    try {
      fileName = decodeURIComponent(fileName);
    } catch (error) {
      fileName = "download";
    }

    if (native) {
      native.download(parsed.href);
      return;
    }

    var record = {
      name: fileName,
      address: parsed.href,
      status: "Downloading…"
    };

    downloads.unshift(record);
    renderToolPage();

    fetch(parsed.href)
      .then(function (response) {
        if (!response.ok) {
          throw new Error("The server did not return a file.");
        }
        return response.blob();
      })
      .then(function (blob) {
        var blobUrl = URL.createObjectURL(blob);
        var link = document.createElement("a");
        link.href = blobUrl;
        link.download = fileName;
        link.style.display = "none";
        document.body.appendChild(link);
        link.click();
        link.remove();

        setTimeout(function () {
          URL.revokeObjectURL(blobUrl);
        }, 30000);

        record.status = "Downloaded";
        if (currentPage === "downloads") renderToolPage();
        showToast("Download started: " + fileName);
      })
      .catch(function () {
        var link = document.createElement("a");
        link.href = parsed.href;
        link.download = fileName;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.style.display = "none";
        document.body.appendChild(link);
        link.click();
        link.remove();

        record.status = "Opened original link";
        if (currentPage === "downloads") renderToolPage();
        showToast("The site blocked direct saving; its link was opened.");
      });
  }

  function handleToolAction(action, index) {
    if (action === "bookmark-current") {
      var tab = activeTab();
      if (!tab || !tab.address || tab.isPrivate) {
        showToast("Open a regular page to bookmark it.");
        return;
      }

      var alreadySaved = bookmarks.some(function (item) {
        return item.address === tab.address;
      });
      if (alreadySaved) {
        showToast("This page is already bookmarked.");
        return;
      }

      bookmarks.unshift({ title: tab.title, address: tab.address });
      saveState();
      renderToolPage();
      showToast("Bookmark saved.");
      return;
    }

    if (action === "visit-history" && historyItems[index]) {
      openSavedAddress(historyItems[index]);
      return;
    }

    if (action === "visit-bookmark" && bookmarks[index]) {
      openSavedAddress(bookmarks[index]);
      return;
    }

    if (action === "remove-bookmark" && bookmarks[index]) {
      bookmarks.splice(index, 1);
      saveState();
      renderToolPage();
      showToast("Bookmark removed.");
      return;
    }

    if (action === "restore-tab" && closedTabs[index]) {
      var savedTab = closedTabs.splice(index, 1)[0];
      var restoredTab = {
        id: nextId++,
        title: savedTab.title,
        address: savedTab.address,
        history: savedTab.history.slice(),
        position: savedTab.position,
        closing: false,
        isPrivate: false,
        grouped: savedTab.grouped,
        web: false,
        canBack: false,
        canForward: false,
        desktop: false,
        showHome: false,
        audible: false,
        muted: false,
        zoom: 100
      };
      if (native && isWebAddress(savedTab.address)) {
        restoredTab.web = true;
        native.navigate(restoredTab.id, savedTab.address, !!restoredTab.desktop);
      }
      tabs.push(restoredTab);
      activeId = restoredTab.id;
      currentPage = "browser";
      showingOverview = false;
      render();
      tabsBox.scrollLeft = tabsBox.scrollWidth;
      return;
    }

    if (action === "clear-history") {
      historyItems = [];
      saveState();
      renderToolPage();
      showToast("Browsing history cleared.");
    }
  }

  function renderPage() {
    var tab = activeTab();
    var isHome = !tab || tab.address === "" || !!tab.showHome;

    if (showingOverview) {
      homePage.style.display = "none";
      result.classList.remove("show");
      toolView.hidden = true;
      overview.classList.add("show");
      setAddress("ASSN://tabs");
      back.disabled = true;
      forward.disabled = true;
      return;
    }

    overview.classList.remove("show");
    if (currentPage !== "browser") {
      homePage.style.display = "none";
      result.classList.remove("show");
      toolView.hidden = false;
      setAddress("ASSN://" + currentPage);
      back.disabled = true;
      forward.disabled = true;
      renderToolPage();
      return;
    }

    toolView.hidden = true;
    homePage.style.display = isHome ? "grid" : "none";
    result.classList.toggle("show", !isHome && !tab.web);

    if (isHome) {
      setAddress("");
    } else if (tab.web) {
      if (document.activeElement !== addressInput) {
        setAddress(displayAddress(tab.address, tab.title));
      }
    } else {
      setAddress(tab.address);
      resultUrl.textContent = tab.address;
      resultTitle.textContent = 'Results for "' + tab.title + '"';
      resultText.textContent =
        "This is an ASSN browser preview. Connect your own search or web service here to create a live browsing experience.";
    }

    if (tab && tab.web) {
      if (tab.showHome) {
        /* Stepped back to the start page: forward returns to the website. */
        back.disabled = true;
        forward.disabled = false;
      } else {
        /* From the first page, back returns to the start page. */
        back.disabled = false;
        forward.disabled = !tab.canForward;
      }
      return;
    }

    back.disabled = !tab || tab.position === 0;
    forward.disabled =
      !tab || tab.position >= tab.history.length - 1;
  }

  function render() {
    renderTabs();
    renderCards();
    renderPage();
    updateCounter();
    counter.classList.toggle("open", showingOverview);
    counter.disabled = isClearing;
    newTab.disabled = isClearing;
    updateMenuLabels();
    syncNative();
  }

  function closeTab(id, event) {
    event.stopPropagation();

    var index = -1;
    var i;

    for (i = 0; i < tabs.length; i++) {
      if (tabs[i].id === id) index = i;
    }

    if (index < 0 || tabs[index].closing) return;
    tabs[index].closing = true;

    var element = tabsBox.querySelector('[data-id="' + id + '"]');
    if (element) element.classList.add("closing");
    var cardElement = cards.querySelector('.card[data-id="' + id + '"]');
    if (cardElement) cardElement.classList.add("closing");

    setTimeout(function () {
      var oldCardPositions = getCardPositions();
      var removeIndex = -1;
      var j;
      for (j = 0; j < tabs.length; j++) {
        if (tabs[j].id === id) removeIndex = j;
      }
      if (removeIndex < 0) return;

      var closedTab = tabs[removeIndex];
      if (!closedTab.isPrivate) {
        closedTabs.unshift({
          title: closedTab.title,
          address: closedTab.address,
          history: closedTab.history.slice(),
          position: closedTab.position,
          grouped: closedTab.grouped
        });
        closedTabs = closedTabs.slice(0, 20);
      }

      tabs.splice(removeIndex, 1);
      if (native) native.closeTab(id);

      if (tabs.length === 0) {
        makeTab(false);
        return;
      }

      if (!activeTab()) {
        activeId = tabs[Math.max(0, removeIndex - 1)].id;
      }

      render();
      animateCardReflow(oldCardPositions);
    }, 250);
  }

  function clearAllTabs() {
    if (isClearing || tabs.length === 0) return;

    closeMenu();
    currentPage = "browser";
    isClearing = true;
    showingOverview = true;

    var tabElements = tabsBox.querySelectorAll(".tab");
    var cardElements = cards.querySelectorAll(".card");
    var i;

    for (i = 0; i < tabElements.length; i++) {
      tabElements[i].classList.add("clearing");
    }

    for (i = 0; i < cardElements.length; i++) {
      cardElements[i].classList.add("clearing");
    }

    overviewClear.disabled = true;
    overviewPlus.disabled = true;
    emptyNewTab.disabled = true;
    counter.disabled = true;
    newTab.disabled = true;

    mintSweep.classList.remove("play");
    void mintSweep.offsetWidth;
    mintSweep.classList.add("play");

    setTimeout(function () {
      tabs = [];
      activeId = 0;
      isClearing = false;
      if (native) native.closeAllTabs();
      render();
    }, 500);

    setTimeout(function () {
      mintSweep.classList.remove("play");
    }, 940);
  }

  function submit(value) {
    var text = value.trim();
    var tab = activeTab();
    if (!text || !tab) return;

    showingOverview = false;
    currentPage = "browser";

    if (native) {
      var target = resolveInput(text);
      tab.showHome = false;
      tab.web = true;
      tab.address = target;
      tab.title = shorten(text);
      native.navigate(tab.id, target, !!tab.desktop);
      render();
      return;
    }

    var address = /^https?:\/\//i.test(text)
      ? text
      : "search.assn/" + text.replace(/\s+/g, "-");

    tab.address = address;
    tab.title = shorten(text);
    tab.history = tab.history.slice(0, tab.position + 1);
    tab.history.push(address);
    tab.position = tab.history.length - 1;

    if (!tab.isPrivate) {
      recordHistory(tab.title, address);
      saveState();
    }

    render();
  }

  newTab.onclick = function () {
    makeTab(true);
  };

  counter.onclick = function () {
    if (isClearing) return;
    currentPage = "browser";
    showingOverview = tabs.length === 0 ? true : !showingOverview;
    render();
  };

  menuButton.onclick = function (event) {
    event.stopPropagation();
    var isOpen = menuPanel.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", isOpen ? "true" : "false");
    syncNative();
  };

  menuPanel.onclick = function (event) {
    var option = event.target.closest("[data-menu-action]");
    if (!option) return;

    var action = option.getAttribute("data-menu-action");
    closeMenu();

    if (action === "new-tab") {
      makeTab(true, false);
    } else if (action === "private-tab") {
      makeTab(true, true);
    } else if (action === "group") {
      var tab = activeTab();
      if (!tab) {
        showToast("Open a tab first.");
        return;
      }
      tab.grouped = !tab.grouped;
      render();
      showToast(tab.grouped ? "Tab moved to a group." : "Tab removed from its group.");
    } else if (action === "desktop-mode") {
      var siteTab = activeTab();
      if (!siteTab) {
        showToast("Open a tab first.");
        return;
      }
      if (!native) {
        showToast("Desktop mode works in the Android app.");
        return;
      }
      siteTab.desktop = !siteTab.desktop;
      native.setDesktop(siteTab.id, siteTab.desktop);
      updateMenuLabels();
      showToast(siteTab.desktop ? "Desktop mode on" : "Mobile mode on");
    } else {
      openToolPage(action);
    }
  };

  document.addEventListener("click", function (event) {
    if (!menuPanel.contains(event.target) && event.target !== menuButton) {
      closeMenu();
    }
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") closeMenu();
  });

  toolBack.onclick = function () {
    currentPage = "browser";
    render();
  };

  toolContent.onclick = function (event) {
    var actionButton = event.target.closest("[data-tool-action]");
    if (!actionButton) return;
    handleToolAction(
      actionButton.getAttribute("data-tool-action"),
      Number(actionButton.getAttribute("data-index"))
    );
  };

  toolContent.onsubmit = function (event) {
    if (event.target.id !== "downloadForm") return;
    event.preventDefault();
    var downloadInput = document.getElementById("downloadUrl");
    startDownload(downloadInput.value.trim());
  };

  overviewPlus.onclick = function () {
    makeTab(true);
  };

  overviewClear.onclick = clearAllTabs;

  emptyNewTab.onclick = function () {
    makeTab(true);
  };

  document.getElementById("homeButton").onclick = function () {
    if (isClearing) return;
    var tab = activeTab();
    if (!tab) {
      makeTab(false);
      return;
    }
    currentPage = "browser";
    showingOverview = false;
    tab.title = tab.isPrivate ? "Private tab" : "New tab";
    tab.address = "";
    tab.history = [""];
    tab.position = 0;
    if (native && tab.web) native.closeTab(tab.id);
    tab.web = false;
    tab.canBack = false;
    tab.canForward = false;
    tab.showHome = false;
    tab.audible = false;
    tab.muted = false;
    render();
  };

  reloadButton.onclick = function () {
    if (isClearing) return;
    var tab = activeTab();
    if (native && tab && tab.web) {
      native.reload(tab.id);
    } else {
      render();
    }
    bump(reloadButton, "spinning");
  };

  back.onclick = function () {
    var tab = activeTab();
    if (native && tab && tab.web) {
      if (tab.showHome) return;
      if (tab.canBack) {
        native.goBack(tab.id);
      } else {
        tab.showHome = true;
        render();
      }
      return;
    }
    if (!tab || tab.position === 0) return;
    tab.position--;
    tab.address = tab.history[tab.position];
    render();
  };

  forward.onclick = function () {
    var tab = activeTab();
    if (native && tab && tab.web) {
      if (tab.showHome) {
        tab.showHome = false;
        render();
        return;
      }
      native.goForward(tab.id);
      return;
    }
    if (!tab || tab.position >= tab.history.length - 1) return;
    tab.position++;
    tab.address = tab.history[tab.position];
    render();
  };

  addressForm.onsubmit = function (event) {
    event.preventDefault();
    addressInput.blur();
    submit(addressInput.value);
  };

  searchForm.onsubmit = function (event) {
    event.preventDefault();
    searchInput.blur();
    submit(searchInput.value);
    searchInput.value = "";
  };

  /* Select the whole address only when the user taps the bar. */
  var addressWasFocused = false;
  addressInput.addEventListener("pointerdown", function () {
    addressWasFocused = document.activeElement === addressInput;
  });
  addressInput.addEventListener("click", function () {
    if (!addressWasFocused) addressInput.select();
  });

  zoomOut.onclick = function () {
    var tab = activeTab();
    changeZoom((tab ? tab.zoom : 100) - ZOOM_STEP);
  };

  zoomIn.onclick = function () {
    var tab = activeTab();
    changeZoom((tab ? tab.zoom : 100) + ZOOM_STEP);
  };

  zoomValue.onclick = function () {
    changeZoom(100);
  };

  overviewBack.onclick = function () {
    if (isClearing) return;
    if (tabs.length === 0) {
      makeTab(false);
      return;
    }
    showingOverview = false;
    render();
  };

  /* ---- Calls coming from the Android app ---- */

  window.assnPageInfo = function (id, url, title, canBack, canForward) {
    var tab = null;
    var i;
    for (i = 0; i < tabs.length; i++) {
      if (tabs[i].id === id) tab = tabs[i];
    }
    if (!tab || !tab.web || !isWebAddress(url)) return;

    var host = url;
    try {
      host = new URL(url).hostname;
    } catch (error) {}

    var cleanTitle = title && title !== url ? title : host;
    if (isSearchAddress(url)) {
      cleanTitle = (searchQuery(url, title) || "Search") + " \u2013 ASSN";
    }
    var changed =
      tab.address !== url ||
      tab.title !== cleanTitle ||
      tab.canBack !== !!canBack ||
      tab.canForward !== !!canForward;

    tab.address = url;
    tab.title = cleanTitle;
    tab.canBack = !!canBack;
    tab.canForward = !!canForward;

    if (!tab.isPrivate) {
      recordHistory(cleanTitle, url);
      saveState();
    }

    if (changed) render();
  };

  window.assnTabAudio = function (id, audible, muted) {
    var i;
    for (i = 0; i < tabs.length; i++) {
      if (tabs[i].id === id) {
        if (tabs[i].audible !== !!audible || tabs[i].muted !== !!muted) {
          tabs[i].audible = !!audible;
          tabs[i].muted = !!muted;
          renderTabs();
        }
      }
    }
  };

  window.assnDownloadStarted = function (name, address) {
    downloads.unshift({ name: name, address: address, status: "Started" });
    downloads = downloads.slice(0, 50);
    if (currentPage === "downloads") renderToolPage();
  };

  window.assnHandleBack = function () {
    if (menuPanel.classList.contains("open")) {
      closeMenu();
      return true;
    }
    if (showingOverview && tabs.length > 0) {
      showingOverview = false;
      render();
      return true;
    }
    if (currentPage !== "browser") {
      currentPage = "browser";
      render();
      return true;
    }
    var backTab = activeTab();
    if (native && backTab && backTab.web && !backTab.showHome && !backTab.canBack) {
      /* First page of the tab: Back returns to the ASSN start page. */
      backTab.showHome = true;
      render();
      return true;
    }
    return false;
  };

  loadState();
  makeTab(false);
})();
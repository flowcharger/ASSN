/* Runs inside Google's results page (www.google.*, /search) and gives it the
   ASSN look: whitish green background and "ASSN" where the Google logo is. */
(function () {
  try {
    if (!/^(www\.)?google\.(com?\.)?[a-z]{2,3}$/.test(location.hostname) || location.pathname !== "/search") {
      return;
    }

    var GREEN = "#e9f5ea";
    var INK = "#173121";
    var LINK = "#1d5c3a";
    var VISITED = "#3f6f52";
    var SOFT = "#4b7a5c";
    var LINE = "#c8dfcb";

    var css =
      "html{background:" + GREEN + "!important;color-scheme:light!important}" +
      "body{background:" + GREEN + "!important}" +
      "body *:not(img):not(svg):not(video):not(canvas):not(picture):not(input):not(button):not(textarea):not(select)" +
      "{background-color:transparent!important}" +
      "body *{color:" + INK + "!important;border-color:" + LINE + "!important}" +
      "body a,body a *{color:" + LINK + "!important}" +
      "body a:visited,body a:visited *{color:" + VISITED + "!important}" +
      "body cite,body cite *{color:" + SOFT + "!important}" +
      "body input,body textarea,body select{background-color:#f8fcf8!important;color:" + INK + "!important}" +
      "body .assn-logo{display:inline-block!important;color:#2e4b37!important;" +
      "font:900 22px Arial,Helvetica,sans-serif!important;letter-spacing:.14em!important;" +
      "padding:0 10px!important;text-decoration:none!important}" +
      "body .assn-banner{display:block!important;text-align:center!important;padding:10px 0 6px!important;" +
      "font-size:24px!important}";

    function style() {
      var node = document.getElementById("assn-search-style");
      if (!node) {
        node = document.createElement("style");
        node.id = "assn-search-style";
        (document.head || document.documentElement).appendChild(node);
      }
      if (node.textContent !== css) node.textContent = css;
    }

    function title() {
      var query = "";
      try {
        query = new URLSearchParams(location.search).get("q") || "";
      } catch (error) {}
      if (!query) {
        var box = document.querySelector("input[name=q],textarea[name=q]");
        query = box ? box.value : "";
      }
      var wanted = (query ? query + " – " : "") + "ASSN";
      if (document.title !== wanted) document.title = wanted;
    }

    /* Swap the Google logo (only the one in the header area) for "ASSN". */
    function logo() {
      var selectors = [
        "a#logo", "#logo", "a[aria-label='Google']", "[aria-label='Google']",
        "a[title='Go to Google Home']", "a[href^='/webhp']", "a[href*='/webhp?']",
        "svg[aria-label='Google']", "img[alt='Google']", "img[src*='googlelogo']",
        ".logo", "a[href='/']"
      ];
      var done = 0;
      var i, j, list, el, target, tag, box, span;
      for (i = 0; i < selectors.length; i++) {
        list = document.querySelectorAll(selectors[i]);
        for (j = 0; j < list.length; j++) {
          el = list[j];
          if (el.classList && el.classList.contains("assn-logo")) continue;
          tag = String(el.tagName).toLowerCase();
          target = tag === "img" || tag === "svg" || tag === "picture" ? el.closest("a") || el : el;
          if (target.getAttribute("data-assn")) continue;
          box = target.getBoundingClientRect();
          if (box.width === 0 && box.height === 0) continue;
          if (box.top > 200 || box.width > 360 || box.height > 130) continue;
          target.setAttribute("data-assn", "1");
          span = document.createElement("span");
          span.className = "assn-logo";
          span.textContent = "ASSN";
          if (target === el && tag !== "a" && tag !== "div" && tag !== "span") {
            target.parentNode.replaceChild(span, target);
          } else {
            while (target.firstChild) target.removeChild(target.firstChild);
            target.appendChild(span);
          }
          done++;
        }
      }
      return done;
    }

    /* If Google's header can't be recognised, still put ASSN on top. */
    function banner() {
      if (!document.body || document.querySelector(".assn-logo")) return;
      var bar = document.createElement("div");
      bar.className = "assn-logo assn-banner";
      bar.textContent = "ASSN";
      document.body.insertBefore(bar, document.body.firstChild);
    }

    /* Sticky bars and pop-ups need a solid colour or text would show through. */
    function solid() {
      var list = document.querySelectorAll("body *");
      var max = Math.min(list.length, 3500);
      var i, el, role, modal, position, height;
      for (i = 0; i < max; i++) {
        el = list[i];
        if (el.__assnSolid) continue;
        role = el.getAttribute("role");
        modal = role === "dialog" || role === "alertdialog" || el.getAttribute("aria-modal") === "true";
        position = window.getComputedStyle(el).position;
        if (!modal && position !== "fixed" && position !== "sticky") continue;
        if (!modal) {
          height = el.getBoundingClientRect().height;
          if (height > window.innerHeight * 0.7) continue;
        }
        el.__assnSolid = true;
        el.style.setProperty("background-color", GREEN, "important");
      }
    }

    function apply() {
      style();
      title();
      logo();
      solid();
    }

    apply();

    if (!window.__assnGoogleLook) {
      window.__assnGoogleLook = true;
      var runs = 0;
      var timer = setInterval(function () {
        runs++;
        apply();
        if (runs === 3) banner();
        if (runs >= 12) clearInterval(timer);
      }, 700);

      if (window.MutationObserver) {
        var waiting = false;
        new MutationObserver(function () {
          if (waiting) return;
          waiting = true;
          setTimeout(function () {
            waiting = false;
            apply();
          }, 800);
        }).observe(document.documentElement, { childList: true, subtree: true });
      }
    }
  } catch (error) {}
})();

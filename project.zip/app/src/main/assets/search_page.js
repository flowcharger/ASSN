/* Runs inside Google's results page (www.google.*, /search) and gives it the
   Air look: white background and "Air" where the Google logo is. */
(function () {
  try {
    if (!/^(www\.)?google\.(com?\.)?[a-z]{2,3}$/.test(location.hostname) || location.pathname !== "/search") {
      return;
    }

    var GREEN = "#ffffff";
    var INK = "#1b1f1d";
    var LINK = "#2457c5";
    var VISITED = "#6a4fa3";
    var SOFT = "#5d6761";
    var LINE = "#e3e6e3";

    var css =
      "html{background:" + GREEN + "!important;color-scheme:light!important}" +
      "body{background:" + GREEN + "!important}" +
      "body *:not(img):not(svg):not(video):not(canvas):not(picture):not(input):not(button):not(textarea):not(select)" +
      "{background-color:transparent!important}" +
      "body *{color:" + INK + "!important;border-color:" + LINE + "!important}" +
      "body a,body a *{color:" + LINK + "!important}" +
      "body a:visited,body a:visited *{color:" + VISITED + "!important}" +
      "body cite,body cite *{color:" + SOFT + "!important}" +
      "body input,body textarea,body select{background-color:transparent!important;color:" + INK + "!important}" +
      ".assn-lb::before,.assn-la::after{background:#eceeec!important;color:" + INK + "!important}" +
      "body .assn-logo{display:inline-block!important;color:#1b1f1d!important;" +
      "font:700 28px Arial,Helvetica,sans-serif!important;letter-spacing:.01em!important;" +
      "padding:0 10px!important;text-decoration:none!important}" +
      "body .assn-banner{display:block!important;text-align:center!important;padding:10px 0 6px!important;" +
      "font-size:24px!important}";

    function style() {
      var node = document.getElementById("assn-search-style");
      if (!node) {
        node = document.createElement("style");
        node.id = "assn-search-style";
        (document.head || document.documentElement).appendChild(node);
      }
      if (node.textContent !== css) node.textContent = css;
    }

    function title() {
      var query = "";
      try {
        query = new URLSearchParams(location.search).get("q") || "";
      } catch (error) {}
      if (!query) {
        var box = document.querySelector("input[name=q],textarea[name=q]");
        query = box ? box.value : "";
      }
      var wanted = (query ? query + " – " : "") + "Air";
      if (document.title !== wanted) document.title = wanted;
    }

    /* Swap the Google logo (only the one in the header area) for "Air". */
    function logo() {
      var selectors = [
        "a#logo", "#logo", "a[aria-label='Google']", "[aria-label='Google']",
        "a[title='Go to Google Home']", "a[href^='/webhp']", "a[href*='/webhp?']",
        "svg[aria-label='Google']", "img[alt='Google']", "img[src*='googlelogo']",
        ".logo", "a[href='/']"
      ];
      var done = 0;
      var i, j, list, el, target, tag, box, span;
      for (i = 0; i < selectors.length; i++) {
        list = document.querySelectorAll(selectors[i]);
        for (j = 0; j < list.length; j++) {
          el = list[j];
          if (el.classList && el.classList.contains("assn-logo")) continue;
          tag = String(el.tagName).toLowerCase();
          target = tag === "img" || tag === "svg" || tag === "picture" ? el.closest("a") || el : el;
          if (target.getAttribute("data-assn")) continue;
          box = target.getBoundingClientRect();
          if (box.width === 0 && box.height === 0) continue;
          if (box.top > 200 || box.width > 360 || box.height > 130) continue;
          target.setAttribute("data-assn", "1");
          span = document.createElement("span");
          span.className = "assn-logo";
          span.textContent = "Air";
          if (target === el && tag !== "a" && tag !== "div" && tag !== "span") {
            target.parentNode.replaceChild(span, target);
          } else {
            while (target.firstChild) target.removeChild(target.firstChild);
            target.appendChild(span);
          }
          done++;
        }
      }
      return done;
    }

    /* If Google's header can't be recognised, still put Air on top. */
    function banner() {
      if (!document.body || document.querySelector(".assn-logo")) return;
      var bar = document.createElement("div");
      bar.className = "assn-logo assn-banner";
      bar.textContent = "Air";
      document.body.insertBefore(bar, document.body.firstChild);
    }

    /* Sticky bars and pop-ups need a solid colour or text would show through. */
    function solid() {
      var list = document.querySelectorAll("body *");
      var max = Math.min(list.length, 3500);
      var i, el, role, modal, position, height;
      for (i = 0; i < max; i++) {
        el = list[i];
        if (el.__assnSolid) continue;
        role = el.getAttribute("role");
        modal = role === "dialog" || role === "alertdialog" || el.getAttribute("aria-modal") === "true";
        position = window.getComputedStyle(el).position;
        if (!modal && position !== "fixed" && position !== "sticky") continue;
        if (!modal) {
          height = el.getBoundingClientRect().height;
          if (height > window.innerHeight * 0.7) continue;
        }
        el.__assnSolid = true;
        el.style.setProperty("background-color", GREEN, "important");
      }
    }

    /* Google's dark-theme skeleton bars and fades use gradients. */
    function flatten() {
      var list = document.querySelectorAll("body *");
      var max = Math.min(list.length, 3500);
      var i, el, cs, r;
      for (i = 0; i < max; i++) {
        el = list[i];
        if (el.__assnFlat || el.children.length > 0) continue;
        if (/^(IMG|SVG|VIDEO|CANVAS|PICTURE|INPUT|TEXTAREA)$/i.test(el.tagName)) continue;
        cs = window.getComputedStyle(el);
        if (!cs || cs.backgroundImage.indexOf("gradient") < 0) continue;
        r = el.getBoundingClientRect();
        el.__assnFlat = true;
        el.style.setProperty("background-image", "none", "important");
        el.style.setProperty("background-color",
          "transparent", "important");
      }
    }

    /* Hide any leftover logo-shaped picture near the top (e.g. the dark-theme wordmark). */
    function hideLogoLike() {
      var list = document.querySelectorAll("img,svg,canvas,[role=img]");
      var i, el, r;
      for (i = 0; i < list.length; i++) {
        el = list[i];
        if (el.__assnLogoChecked) continue;
        if (el.closest && el.closest("form,[role=search],[role=tablist],nav,button,a[role=link] ")) continue;
        r = el.getBoundingClientRect();
        if (r.top > 280 || r.width < 70 || r.width > 330 || r.height < 18 || r.height > 120) continue;
        if (r.width / r.height < 2) continue;
        el.__assnLogoChecked = true;
        el.style.setProperty("visibility", "hidden", "important");
      }
    }

    /* Google's AI answer parts come with dark surfaces: turn dark grey/black boxes into light ones. */
    function rgba(str) {
      var m = /rgba?\(([^)]+)\)/.exec(str || "");
      if (!m) return null;
      var p = m[1].split(/[ ,\/]+/).filter(Boolean).map(parseFloat);
      return { r: p[0], g: p[1], b: p[2], a: p.length > 3 && !isNaN(p[3]) ? p[3] : 1 };
    }

    function isDark(c) {
      if (!c || c.a < 0.4) return false;
      var lum = (0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b) / 255;
      var spread = Math.max(c.r, c.g, c.b) - Math.min(c.r, c.g, c.b);
      return lum < 0.3 && spread < 70;
    }

    function lighten() {
      var list = document.querySelectorAll("body *");
      var max = Math.min(list.length, 3500);
      var i, el, cs, bi, m, k, pseudo, pcs;
      var pseudos = ["::before", "::after"];
      for (i = 0; i < max; i++) {
        el = list[i];
        if (el.__assnLit) continue;
        if (/^(IMG|SVG|VIDEO|CANVAS|PICTURE|PATH|G|CIRCLE|RECT|USE|SOURCE)$/i.test(el.tagName)) continue;
        el.__assnLit = true;
        cs = window.getComputedStyle(el);
        var dark = isDark(rgba(cs.backgroundColor));
        bi = cs.backgroundImage || "";
        if (!dark && bi.indexOf("gradient") > -1) {
          m = /rgba?\([^)]+\)/.exec(bi);
          if (m && isDark(rgba(m[0]))) {
            dark = true;
            el.style.setProperty("background-image", "none", "important");
          }
        }
        if (!dark && !/^(BUTTON|A|INPUT)$/i.test(el.tagName)) {
          var cc = rgba(cs.backgroundColor);
          var plain = (el.textContent || "").length > 12 && el.children.length === 0;
          if (cc && cc.a >= 0.4 && plain && (0.2126 * cc.r + 0.7152 * cc.g + 0.0722 * cc.b) / 255 < 0.35) {
            el.style.setProperty("background-color", "#dbe8fd", "important");
            el.style.setProperty("color", INK, "important");
          }
        }
        if (dark) {
          el.style.setProperty("background-color", "#f1f3f4", "important");
          el.style.setProperty("color", INK, "important");
        }
        for (k = 0; k < pseudos.length; k++) {
          try {
            pcs = window.getComputedStyle(el, pseudos[k]);
            if (pcs && pcs.content && pcs.content !== "none" && pcs.content !== "normal" &&
                isDark(rgba(pcs.backgroundColor))) {
              el.classList.add(k === 0 ? "assn-lb" : "assn-la");
            }
          } catch (error) {}
        }
      }
    }

    /* Google Images: when the picture preview opens above where you are scrolled to,
       keep it on screen instead of making you scroll back to the top. */
    function imagesFix() {
      if (!/[?&](tbm=isch|udm=2)(&|$)/.test(location.search) || window.__assnImgFix) return;
      window.__assnImgFix = true;
      var before = [];
      var clickedArea = 0;

      function area(el) {
        var r = el.getBoundingClientRect();
        return r.width * r.height;
      }

      function big(img) {
        var r = img.getBoundingClientRect();
        return r.width >= 200 && r.height >= 150;
      }

      function check() {
        var imgs = document.querySelectorAll("img"), i, r, img, box, p, pr, best = null, bestArea = 0, a;
        for (i = 0; i < imgs.length; i++) {
          img = imgs[i];
          if (before.indexOf(img) > -1 || !big(img)) continue;
          r = img.getBoundingClientRect();
          if (r.bottom >= 0) continue;
          a = r.width * r.height;
          if (clickedArea && a < clickedArea * 1.3) continue;
          if (a > bestArea) { best = img; bestArea = a; }
        }
        if (!best) return;
        box = best;
        p = best.parentElement;
        while (p && p !== document.body && p !== document.documentElement) {
          pr = p.getBoundingClientRect();
          if (pr.width > window.innerWidth * 1.02 || pr.height > window.innerHeight * 1.4) break;
          box = p;
          p = p.parentElement;
        }
        if (box === best || box.__assnPinned) return;
        pr = box.getBoundingClientRect();
        box.__assnPinned = true;
        box.style.setProperty("position", "fixed", "important");
        box.style.setProperty("top", "0", "important");
        box.style.setProperty("left", Math.max(0, pr.left) + "px", "important");
        box.style.setProperty("width", Math.min(window.innerWidth, Math.max(pr.width, 300)) + "px", "important");
        box.style.setProperty("max-height", "100vh", "important");
        box.style.setProperty("overflow", "auto", "important");
        box.style.setProperty("z-index", "2147483000", "important");
        box.style.setProperty("background-color", "#ffffff", "important");
        box.style.setProperty("box-shadow", "0 8px 30px rgba(0,0,0,.25)", "important");
      }

      document.addEventListener("click", function (e) {
        var imgs = document.querySelectorAll("img"), i, hit = null;
        before = [];
        for (i = 0; i < imgs.length; i++) {
          if (big(imgs[i])) before.push(imgs[i]);
        }
        try {
          hit = e.target && e.target.querySelector ? (e.target.tagName === "IMG" ? e.target : e.target.querySelector("img")) : null;
        } catch (error) {}
        clickedArea = hit ? area(hit) : 0;
        var n = 0;
        var timer = setInterval(function () {
          check();
          n++;
          if (n >= 12) clearInterval(timer);
        }, 250);
      }, true);
    }

    function apply() {
      style();
      title();
      logo();
      hideLogoLike();
      flatten();
      solid();
      lighten();
    }

    apply();
    imagesFix();

    if (!window.__assnGoogleLook) {
      window.__assnGoogleLook = true;
      var runs = 0;
      var timer = setInterval(function () {
        runs++;
        apply();
        if (runs === 3) banner();
        if (runs >= 12) clearInterval(timer);
      }, 700);

      if (window.MutationObserver) {
        var waiting = false;
        new MutationObserver(function () {
          if (waiting) return;
          waiting = true;
          setTimeout(function () {
            waiting = false;
            apply();
          }, 800);
        }).observe(document.documentElement, { childList: true, subtree: true });
      }
    }
  } catch (error) {}
})();

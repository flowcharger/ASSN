package com.assn.browser;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Air Browser.
 *
 * The interface (tab strip, address bar, menus, tab overview) is the ASSN HTML
 * page in assets/. Every tab's real website runs in its own Chromium WebView
 * placed underneath the interface's top bar.
 */
public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int STORAGE_PERMISSION_REQUEST = 1002;

    /** Pull down this far (dp) at the top of a page to refresh it. */
    private static final int PULL_TRIGGER_DP = 130;

    /** Allowed range of the menu's zoom control, in percent. */
    private static final int ZOOM_MIN = 30;
    private static final int ZOOM_MAX = 130;

    /** Ad and tracker hosts that are blocked while the ad blocker is on. */
    private static final String[] AD_HOSTS = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "pagead2.googlesyndication.com", "google-analytics.com",
        "googletagservices.com", "adnxs.com", "adsrvr.org", "advertising.com", "taboola.com",
        "outbrain.com", "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com",
        "openx.net", "amazon-adsystem.com", "media.net", "moatads.com", "scorecardresearch.com",
        "quantserve.com", "adsafeprotected.com", "2mdn.net", "zedo.com", "smartadserver.com",
        "casalemedia.com", "indexww.com", "bidswitch.net", "contextweb.com", "yieldmo.com",
        "sharethrough.com", "teads.tv", "revcontent.com", "mgid.com", "popads.net",
        "propellerads.com", "exoclick.com", "juicyads.com", "adcolony.com", "applovin.com",
        "unityads.unity3d.com", "hotjar.com", "mixpanel.com", "branch.io", "app-measurement.com"
    };

    /** Hides empty ad boxes left behind by blocked requests. */
    private static final String AD_CSS_SCRIPT =
            "(function(){if(document.getElementById('__assnAds'))return;var s=document.createElement('style');s.id='__assnAds';"
            + "s.textContent='ins.adsbygoogle,.adsbygoogle,[id^=google_ads],[id^=div-gpt-ad],[class*=\\\"ad-slot\\\"],"
            + "iframe[src*=doubleclick],iframe[src*=googlesyndication],.ad-banner,.ad-container,.advert,.advertisement,"
            + "[data-ad-slot],[data-google-query-id]{display:none!important}';(document.head||document.documentElement)"
            + ".appendChild(s);})();";

    /** Lets sound keep playing when the app is not on screen: the page is told it is still visible. */
    private static final String VISIBLE_SCRIPT =
            "(function(){if(window.__assnVis)return;window.__assnVis=true;window.__assnBg=false;try{Object.defineProperty("
            + "document,'hidden',{configurable:true,get:function(){return false;}});Object.defineProperty(document,'visibili"
            + "tyState',{configurable:true,get:function(){return 'visible';}});}catch(e){}['visibilitychange','webkitvisibil"
            + "itychange'].forEach(function(n){window.addEventListener(n,function(e){e.stopImmediatePropagation();},true);do"
            + "cument.addEventListener(n,function(e){e.stopImmediatePropagation();},true);});document.addEventListener('pau"
            + "se',function(e){var m=e.target;if(window.__assnBg&&m&&!m.ended&&m.play){setTimeout(function(){if(window.__ass"
            + "nBg&&m.paused)try{m.play();}catch(x){}},200);}},true);})();";

    private volatile boolean adBlock = true;
    private boolean backgroundPlay = true;
    private boolean serviceOn = false;

    private static final int SEARCH_BG = Color.parseColor("#FFFFFF");
    private static final int NIGHT_BG = Color.parseColor("#121212");

    /** Runs inside every website: reports whether sound is playing and lets the tab-strip speaker button mute the tab. */
    private static final String MEDIA_SCRIPT =
            "(function(){if(window.__assnInit)return;window.__assnInit=true;var muted=false;function all(){return document."
            + "querySelectorAll('video,audio');}function applyMute(){var l=all(),i,m;for(i=0;i<l.length;i++){m=l[i];if(muted)"
            + "{if(!m.__am){m.__am=true;m.__was=m.muted;}m.muted=true;}else if(m.__am){m.muted=!!m.__was;m.__am=false;}}}wind"
            + "ow.__assnAudible=function(){var l=all(),i,m;for(i=0;i<l.length;i++){m=l[i];if(!m.paused&&!m.ended&&m.readyStat"
            + "e>2&&(m.__am||(!m.muted&&m.volume>0)))return true;}return false;};window.__assnSetMuted=function(v){muted=!!v;"
            + "applyMute();};['play','playing','volumechange','loadeddata'].forEach(function(n){document.addEventListener(n,f"
            + "unction(){if(muted)applyMute();},true);});setInterval(function(){if(muted)applyMute();},1500);})();";

    /** Makes the "desktop site" a normal desktop-sized page instead of a zoomed-in one. */
    private static final String DESKTOP_SCRIPT =
            "(function(){try{var w=Math.max(1280,Math.round(window.screen.width||1280));var m=document.querySelector('meta[na"
            + "me=viewport]');if(!m){m=document.createElement('meta');m.setAttribute('name','viewport');(document.head||docum"
            + "ent.documentElement).appendChild(m);}m.setAttribute('content','width='+w);}catch(e){}})();";

    /**
     * Tracks whether the finger went down on a page that is really at its top
     * (the page itself and every scrolling box under the finger). Pull to
     * refresh only starts when this says yes.
     */
    private static final String TOUCH_SCRIPT =
            "(function(){if(window.__assnTouch)return;window.__assnTouch=true;window.__assnTopOk=true;"
            + "document.addEventListener('touchstart',function(e){var d=document.scrollingElement||document.documentElement;"
            + "var ok=(window.pageYOffset||d.scrollTop||0)<=0;var p=e.composedPath?e.composedPath():null;var i,n;"
            + "if(p){for(i=0;i<p.length&&ok;i++){n=p[i];if(n&&n.nodeType===1&&(n.tagName==='IFRAME'||n.scrollTop>0))ok=false;}}"
            + "else{n=e.target;while(ok&&n&&n.nodeType===1){if(n.tagName==='IFRAME'||n.scrollTop>0)ok=false;n=n.parentNode;}}"
            + "window.__assnTopOk=ok;},{capture:true,passive:true});})();";

    /** Height of the tab strip (50) + toolbar (58) in the HTML, in dp. */
    private static final int TOP_BAR_DP = 108;

    private static final String UI_URL = "file:///android_asset/index.html";
    private static final String UI_ASSET_PREFIX = "file:///android_asset/";
    private static final String PREFS_NAME = "assn_prefs";

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    private final Map<Integer, WebView> tabViews = new HashMap<Integer, WebView>();
    private final Set<Integer> desktopTabs = new HashSet<Integer>();
    private final Set<Integer> mutedTabs = new HashSet<Integer>();
    private final Set<Integer> privateTabs = new HashSet<Integer>();
    private final Set<Integer> audibleTabs = new HashSet<Integer>();
    private final Map<Integer, Integer> zoomTabs = new HashMap<Integer, Integer>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private FrameLayout root;
    private FrameLayout contentContainer;
    private FrameLayout fullscreenContainer;
    private WebView uiView;
    private ProgressBar refreshIndicator;
    private boolean refreshing;
    private boolean pullActive;

    private int topBarPx;
    private int activeTabId = 0;
    private boolean webVisible = false;
    private boolean uiExpanded = true;
    private String browserUserAgent;
    private String desktopUserAgent;
    private String searchScript = "";
    private String ytScript = "";

    private FrameLayout.LayoutParams contentParams;
    private boolean chromeHidden = false;
    private int scrollAccum = 0;
    private long lastChromeToggle = 0;

    /** Looks at every tab twice a second-ish to see which ones are playing sound. */
    private final Runnable audioPoll = new Runnable() {
        @Override
        public void run() {
            pollAudio();
            handler.postDelayed(this, 1500);
        }
    };

    /** Safety net: never leave the refresh spinner on screen for long. */
    private final Runnable hideRefresh = new Runnable() {
        @Override
        public void run() {
            pullHide();
        }
    };

    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private ValueCallback<Uri[]> filePathCallback;

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        topBarPx = dp(TOP_BAR_DP);
        searchScript = readAsset("search_page.js");
        ytScript = readAsset("yt_ads.js");

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#E9F5EA"));

        // Websites live here, below the HTML top bar.
        contentContainer = new FrameLayout(this);
        contentParams = new FrameLayout.LayoutParams(MATCH, MATCH);
        contentParams.topMargin = topBarPx;
        root.addView(contentContainer, contentParams);

        // Pull-to-refresh spinner. It slides out from underneath the top bar.
        refreshIndicator = new ProgressBar(this);
        refreshIndicator.setPadding(dp(9), dp(9), dp(9), dp(9));
        refreshIndicator.setIndeterminateTintList(
                ColorStateList.valueOf(Color.parseColor("#2E4B37")));
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.parseColor("#F2FAF2"));
        circle.setStroke(dp(1), Color.parseColor("#C8DFCB"));
        refreshIndicator.setBackground(circle);
        refreshIndicator.setElevation(dp(4));
        refreshIndicator.setVisibility(View.GONE);
        FrameLayout.LayoutParams indicatorParams = new FrameLayout.LayoutParams(
                dp(42), dp(42), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        indicatorParams.topMargin = topBarPx;
        root.addView(refreshIndicator, indicatorParams);

        // The ASSN interface sits on top. It is full screen whenever it needs
        // the whole page (home, tab overview, menus) and only the top bar
        // while a website is showing.
        uiView = new WebView(this);
        uiView.setBackgroundColor(Color.TRANSPARENT);
        configureUiView();
        root.addView(uiView, new FrameLayout.LayoutParams(MATCH, MATCH));

        // Full screen video player.
        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);

        browserUserAgent = buildBrowserUserAgent();
        desktopUserAgent = buildDesktopUserAgent(browserUserAgent);

        CookieManager.getInstance().setAcceptCookie(true);

        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    STORAGE_PERMISSION_REQUEST);
        }

        uiView.loadUrl(UI_URL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(audioPoll);
        uiView.onPause();
        if (backgroundPlay && !audibleTabs.isEmpty()) {
            // Sound is playing: keep the pages running and the app alive.
            try {
                Intent svc = new Intent(this, PlaybackService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
                else startService(svc);
                serviceOn = true;
            } catch (Exception ignored) {
            }
            for (WebView view : tabViews.values()) {
                view.evaluateJavascript(VISIBLE_SCRIPT + "window.__assnBg=true;", null);
            }
        } else {
            for (WebView view : tabViews.values()) {
                view.onPause();
            }
        }
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(audioPoll);
        handler.postDelayed(audioPoll, 1500);
        uiView.onResume();
        for (WebView view : tabViews.values()) {
            view.onResume();
        }
        for (WebView view : tabViews.values()) {
            view.evaluateJavascript("window.__assnBg=false;", null);
        }
        if (serviceOn) {
            stopService(new Intent(this, PlaybackService.class));
            serviceOn = false;
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        hideCustomView();
        for (WebView view : new ArrayList<WebView>(tabViews.values())) {
            destroyView(view);
        }
        tabViews.clear();
        root.removeView(uiView);
        uiView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustomView();
            return;
        }

        // Let the ASSN page close menus / overview / tool pages first.
        uiView.evaluateJavascript(
                "(window.assnHandleBack&&window.assnHandleBack())?'1':'0'",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if ("\"1\"".equals(value)) {
                            return;
                        }
                        WebView view = tabViews.get(activeTabId);
                        if (webVisible && view != null && view.canGoBack()) {
                            view.goBack();
                        } else {
                            finish();
                        }
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // ------------------------------------------------------------------
    // The ASSN interface WebView
    // ------------------------------------------------------------------

    private void configureUiView() {
        WebSettings settings = uiView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setTextZoom(100);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        // The Air interface keeps its own look in any system theme.
        applyDarkening(uiView, false);

        uiView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        uiView.addJavascriptInterface(new Bridge(), "AssnNative");

        uiView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // The interface must never navigate away from its own page.
                return !request.getUrl().toString().startsWith(UI_ASSET_PREFIX);
            }
        });
    }

    private String readAsset(String name) {
        InputStream in = null;
        try {
            in = getAssets().open(name);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int count;
            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
            }
            return out.toString("UTF-8");
        } catch (IOException e) {
            return "";
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignored) {
                    // nothing to do
                }
            }
        }
    }

    /** Chrome-like user agent (without the "; wv" marker some sites block). */
    private String buildBrowserUserAgent() {
        String agent = uiView.getSettings().getUserAgentString();
        if (agent == null) {
            return null;
        }
        agent = agent.replace("; wv)", ")");
        agent = agent.replaceAll("Version/[0-9.]+ ", "");
        return agent;
    }

    // ------------------------------------------------------------------
    // Website tabs
    // ------------------------------------------------------------------

    private WebView createTabView(final int tabId) {
        WebView view = new WebView(this);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setTextZoom(100);
        applyUserAgent(view, desktopTabs.contains(tabId));
        applyCacheMode(view, privateTabs.contains(tabId));
        applyTheme(view, null);
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);
        view.setOnTouchListener(new PullToRefresh(tabId));

        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true);

        // Scrolling down hides the ASSN bars, scrolling up brings them back.
        view.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY,
                    int oldScrollX, int oldScrollY) {
                onTabScrolled(tabId, scrollY, scrollY - oldScrollY);
            }
        });

        view.setWebViewClient(new TabClient(tabId));
        view.setWebChromeClient(new TabChrome(tabId));
        view.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                    String contentDisposition, String mimeType, long contentLength) {
                startDownload(url, userAgent, contentDisposition, mimeType);
            }
        });

        view.setVisibility(View.GONE);
        tabViews.put(tabId, view);
        contentContainer.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH));
        return view;
    }

    private void destroyView(WebView view) {
        view.stopLoading();
        view.setWebViewClient(new WebViewClient());
        view.setWebChromeClient(null);
        contentContainer.removeView(view);
        view.destroy();
    }

    /** InPrivate tabs don't keep cached pages. */
    private static void applyCacheMode(WebView view, boolean isPrivate) {
        view.getSettings().setCacheMode(
                isPrivate ? WebSettings.LOAD_NO_CACHE : WebSettings.LOAD_DEFAULT);
    }

    /** Wipes what an InPrivate tab left in its web view before it goes away. */
    private static void wipePrivateView(WebView view) {
        view.clearCache(true);
        view.clearFormData();
        view.clearHistory();
    }

    private void applyUserAgent(WebView view, boolean desktop) {
        String agent = desktop ? desktopUserAgent : browserUserAgent;
        if (agent != null) {
            view.getSettings().setUserAgentString(agent);
        }
    }

    /** Same Chrome version as the phone agent, but pretending to be a desktop. */
    private static String buildDesktopUserAgent(String mobileAgent) {
        String chrome = "Chrome/120.0.0.0";
        if (mobileAgent != null) {
            Matcher matcher = Pattern.compile("Chrome/[0-9.]+").matcher(mobileAgent);
            if (matcher.find()) {
                chrome = matcher.group();
            }
        }
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                + chrome + " Safari/537.36";
    }

    private void onTabScrolled(int tabId, int scrollY, int dy) {
        if (tabId != activeTabId || !webVisible || uiExpanded) {
            return;
        }
        // Ignore the scroll jitter caused by the bars sliding away or back.
        if (SystemClock.uptimeMillis() - lastChromeToggle < 350) {
            scrollAccum = 0;
            return;
        }
        if (scrollY <= 0) {
            setChromeHidden(false, true);
            return;
        }
        if ((dy > 0) != (scrollAccum > 0)) {
            scrollAccum = 0;
        }
        scrollAccum += dy;
        if (scrollAccum > dp(24)) {
            setChromeHidden(true, true);
        } else if (scrollAccum < -dp(12)) {
            setChromeHidden(false, true);
        }
    }

    /**
     * Slides the tab strip + toolbar off the top (and the page up into the
     * space), or back again. The page is made taller before it slides so it
     * never shows a gap at the bottom.
     */
    private void setChromeHidden(boolean hide, boolean animate) {
        if (hide == chromeHidden) {
            return;
        }
        if (hide && (!webVisible || uiExpanded)) {
            return;
        }
        chromeHidden = hide;
        scrollAccum = 0;
        lastChromeToggle = SystemClock.uptimeMillis();

        float target = hide ? -topBarPx : 0f;
        long duration = animate ? 180 : 0;

        if (hide) {
            contentParams.bottomMargin = -topBarPx;
            contentContainer.setLayoutParams(contentParams);
        }

        uiView.animate().translationY(target).setDuration(duration).start();

        ViewPropertyAnimator pageAnimator =
                contentContainer.animate().translationY(target).setDuration(duration);
        if (!hide) {
            pageAnimator.withEndAction(new Runnable() {
                @Override
                public void run() {
                    if (!chromeHidden) {
                        contentParams.bottomMargin = 0;
                        contentContainer.setLayoutParams(contentParams);
                    }
                }
            });
        }
        pageAnimator.start();
    }

    private void applyLayout() {
        if (!webVisible || uiExpanded) {
            setChromeHidden(false, false);
        }
        for (Map.Entry<Integer, WebView> entry : tabViews.entrySet()) {
            boolean show = webVisible && entry.getKey().intValue() == activeTabId;
            entry.getValue().setVisibility(show ? View.VISIBLE : View.GONE);
        }

        // A website is showing: only the top bar belongs to the interface,
        // unless a menu needs the full screen.
        int wantedHeight = uiExpanded ? MATCH : topBarPx;
        ViewGroup.LayoutParams params = uiView.getLayoutParams();
        if (params.height != wantedHeight) {
            params.height = wantedHeight;
            uiView.setLayoutParams(params);
        }
    }

    private boolean handleUrl(String url) {
        if (url == null) {
            return true;
        }
        String lower = url.toLowerCase(Locale.ROOT);

        if (lower.startsWith("http://") || lower.startsWith("https://")
                || lower.startsWith("about:") || lower.startsWith("javascript:")
                || lower.startsWith("data:") || lower.startsWith("blob:")) {
            return false;
        }

        if (lower.startsWith("file:") || lower.startsWith("content:")) {
            return true;
        }

        // mailto:, tel:, intent:, market: ... hand over to other apps.
        try {
            Intent intent;
            if (lower.startsWith("intent:")) {
                intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setComponent(null);
                intent.setSelector(null);
            } else {
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            }
            startActivity(intent);
        } catch (Exception e) {
            showToast("No app can open this link.");
        }
        return true;
    }

    private class TabClient extends WebViewClient {
        private final int tabId;

        TabClient(int tabId) {
            this.tabId = tabId;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            applyTheme(view, request.getUrl().toString());
            return handleUrl(request.getUrl().toString());
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            if (adBlock && !request.isForMainFrame() && isAdHost(request.getUrl().getHost())) {
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
            return super.shouldInterceptRequest(view, request);
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            applyTheme(view, url);
            if (tabId == activeTabId) {
                setChromeHidden(false, true);
            }
            notifyPage(tabId, view);
        }

        @Override
        public void onPageCommitVisible(WebView view, String url) {
            super.onPageCommitVisible(view, url);
            injectPageScripts(tabId, view, url);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            injectPageScripts(tabId, view, url);
            if (tabId == activeTabId && refreshing) {
                pullHide();
            }
            notifyPage(tabId, view);
        }

        @Override
        public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
            super.doUpdateVisitedHistory(view, url, isReload);
            notifyPage(tabId, view);
        }
    }

    private class TabChrome extends WebChromeClient {
        private final int tabId;

        TabChrome(int tabId) {
            this.tabId = tabId;
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            notifyPage(tabId, view);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            showCustomView(view, callback);
        }

        @Override
        public void onHideCustomView() {
            hideCustomView();
        }

        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                FileChooserParams params) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = callback;
            try {
                startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST);
            } catch (Exception e) {
                filePathCallback = null;
                return false;
            }
            return true;
        }
    }

    // ------------------------------------------------------------------
    // Page colours, injected page scripts, sound
    // ------------------------------------------------------------------

    private boolean isNight() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    @SuppressWarnings("deprecation")
    private void applyDarkening(WebView view, boolean allow) {
        WebSettings settings = view.getSettings();
        if (Build.VERSION.SDK_INT >= 33) {
            settings.setAlgorithmicDarkeningAllowed(allow);
        } else if (Build.VERSION.SDK_INT >= 29) {
            settings.setForceDark(allow ? WebSettings.FORCE_DARK_ON : WebSettings.FORCE_DARK_OFF);
        }
    }

    /**
     * Websites follow the phone's light/dark setting. The ASSN search page is
     * always whitish green, like the home page.
     */
    private void applyTheme(WebView view, String url) {
        if (isSearchUrl(url)) {
            view.setBackgroundColor(SEARCH_BG);
            applyDarkening(view, false);
        } else {
            boolean night = isNight();
            view.setBackgroundColor(night ? NIGHT_BG : Color.WHITE);
            applyDarkening(view, night);
        }
    }

    /** The ASSN search page is Google's results page, restyled by search_page.js. */
    private static boolean isSearchUrl(String url) {
        if (url == null) {
            return false;
        }
        Uri uri = Uri.parse(url);
        String host = uri.getHost();
        String path = uri.getPath();
        if (host == null || path == null) {
            return false;
        }
        host = host.toLowerCase(Locale.ROOT);
        boolean google = host.matches("(www\\.)?google\\.(com?\\.)?[a-z]{2,3}");
        return google && path.equals("/search");
    }

    /** Page zoom: scales the whole page (text, images, layout), 30% to 130%. */
    private void applyZoom(int tabId, WebView view) {
        Integer saved = zoomTabs.get(tabId);
        int percent = saved == null ? 100 : saved.intValue();
        String value = percent == 100 ? "" : percent + "%";
        view.evaluateJavascript(
                "(function(){var d=document.documentElement;if(d)d.style.zoom='" + value + "';})();",
                null);
    }

    private static boolean isYouTube(String url) {
        if (url == null) return false;
        try {
            String host = Uri.parse(url).getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.US);
            return host.equals("youtube.com") || host.endsWith(".youtube.com");
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isAdHost(String host) {
        if (host == null) return false;
        host = host.toLowerCase(Locale.US);
        for (String ad : AD_HOSTS) {
            if (host.equals(ad) || host.endsWith("." + ad)) return true;
        }
        return false;
    }

    private void injectPageScripts(int tabId, WebView view, String url) {
        applyZoom(tabId, view);
        if (adBlock) {
            view.evaluateJavascript(AD_CSS_SCRIPT, null);
        }
        view.evaluateJavascript(MEDIA_SCRIPT, null);
        view.evaluateJavascript(TOUCH_SCRIPT, null);
        if (mutedTabs.contains(tabId)) {
            view.evaluateJavascript("window.__assnSetMuted&&window.__assnSetMuted(true);", null);
        }
        if (desktopTabs.contains(tabId)) {
            view.evaluateJavascript(DESKTOP_SCRIPT, null);
        }
        if (backgroundPlay) {
            view.evaluateJavascript(VISIBLE_SCRIPT, null);
        }
        if (adBlock && isYouTube(url) && ytScript.length() > 0) {
            view.evaluateJavascript(ytScript, null);
        }
        if (isSearchUrl(url) && searchScript.length() > 0) {
            view.evaluateJavascript(searchScript, null);
        }
    }

    private void pollAudio() {
        for (Map.Entry<Integer, WebView> entry : new ArrayList<Map.Entry<Integer, WebView>>(
                tabViews.entrySet())) {
            final int id = entry.getKey().intValue();
            entry.getValue().evaluateJavascript(
                    "(window.__assnAudible?window.__assnAudible():false)",
                    new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            setAudible(id, "true".equals(value));
                        }
                    });
        }
    }

    private void setAudible(int tabId, boolean audible) {
        if (!tabViews.containsKey(tabId)) {
            return;
        }
        boolean was = audibleTabs.contains(tabId);
        if (audible == was) {
            return;
        }
        if (audible) {
            audibleTabs.add(tabId);
        } else {
            audibleTabs.remove(tabId);
        }
        sendAudio(tabId);
    }

    private void sendAudio(int tabId) {
        callJs("window.assnTabAudio&&window.assnTabAudio(" + tabId + ","
                + audibleTabs.contains(tabId) + "," + mutedTabs.contains(tabId) + ");");
    }

    // ------------------------------------------------------------------
    // Pull down at the top of a page to refresh it
    // ------------------------------------------------------------------

    private class PullToRefresh implements View.OnTouchListener {
        private final int tabId;
        private float startX;
        private float startY;
        private boolean tracking;
        private boolean pulling;
        /** 0 = not asked yet, 1 = asking the page, 2 = page is at its top, 3 = it is not. */
        private int topState;
        private int gesture;

        PullToRefresh(int tabId) {
            this.tabId = tabId;
        }

        private void askPageTop(WebView view, final int forGesture) {
            view.evaluateJavascript(
                    "(window.__assnTopOk===true)?'1':'0'",
                    new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            if (forGesture == gesture) {
                                topState = "\"1\"".equals(value) ? 2 : 3;
                            }
                        }
                    });
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = event.getX();
                    startY = event.getY();
                    pulling = false;
                    topState = 0;
                    gesture++;
                    tracking = tabId == activeTabId && webVisible && !uiExpanded
                            && !refreshing && !v.canScrollVertically(-1);
                    return false;

                case MotionEvent.ACTION_MOVE:
                    if (!tracking) {
                        return false;
                    }
                    if (!pulling) {
                        float dy = event.getY() - startY;
                        if (v.canScrollVertically(-1) || dy < -dp(8)) {
                            tracking = false;
                            return false;
                        }
                        if (dy > dp(16) && dy > Math.abs(event.getX() - startX) * 1.5f) {
                            if (topState == 0) {
                                // Ask the page whether it (and every scrolling box
                                // under the finger) is really at the top.
                                topState = 1;
                                askPageTop((WebView) v, gesture);
                                return false;
                            }
                            if (topState == 3) {
                                tracking = false;
                                return false;
                            }
                            if (topState != 2) {
                                return false;
                            }
                            pulling = true;
                            startY = event.getY();
                            // Tell the page its touch is over so it doesn't click or drag.
                            MotionEvent cancel = MotionEvent.obtain(event);
                            cancel.setAction(MotionEvent.ACTION_CANCEL);
                            v.onTouchEvent(cancel);
                            cancel.recycle();
                            pullShow(0f);
                            return true;
                        }
                        return false;
                    }
                    pullShow(Math.max(0f, event.getY() - startY));
                    return true;

                case MotionEvent.ACTION_POINTER_DOWN:
                    // A second finger means pinch-zoom, not a refresh.
                    if (!pulling) {
                        tracking = false;
                    }
                    return pulling;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    boolean wasPulling = pulling;
                    pulling = false;
                    tracking = false;
                    if (wasPulling) {
                        boolean refresh = event.getActionMasked() == MotionEvent.ACTION_UP
                                && event.getY() - startY >= dp(PULL_TRIGGER_DP);
                        pullRelease(tabId, refresh);
                        return true;
                    }
                    return false;

                default:
                    return false;
            }
        }
    }

    private void pullShow(float distance) {
        pullActive = true;
        float shown = Math.min(distance * 0.55f, dp(80));
        refreshIndicator.animate().cancel();
        refreshIndicator.setVisibility(View.VISIBLE);
        refreshIndicator.setTranslationY(shown - dp(42));
        refreshIndicator.setAlpha(Math.min(1f, 0.25f + distance / dp(PULL_TRIGGER_DP)));
    }

    private void pullRelease(int tabId, boolean refresh) {
        pullActive = false;
        WebView view = tabViews.get(tabId);
        if (refresh && view != null) {
            refreshing = true;
            refreshIndicator.setAlpha(1f);
            refreshIndicator.animate().translationY(dp(14)).setDuration(120).start();
            view.reload();
            handler.removeCallbacks(hideRefresh);
            handler.postDelayed(hideRefresh, 8000);
        } else {
            pullHide();
        }
    }

    private void pullHide() {
        pullActive = false;
        refreshing = false;
        handler.removeCallbacks(hideRefresh);
        refreshIndicator.animate().alpha(0f).setDuration(150).withEndAction(new Runnable() {
            @Override
            public void run() {
                if (!pullActive && !refreshing) {
                    refreshIndicator.setVisibility(View.GONE);
                    refreshIndicator.setAlpha(1f);
                }
            }
        }).start();
    }

    // ------------------------------------------------------------------
    // Full screen video
    // ------------------------------------------------------------------

    private void showCustomView(View view, WebChromeClient.CustomViewCallback callback) {
        if (customView != null) {
            callback.onCustomViewHidden();
            return;
        }
        customView = view;
        customViewCallback = callback;
        fullscreenContainer.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH));
        fullscreenContainer.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void hideCustomView() {
        if (customView == null) {
            return;
        }
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;

        WebChromeClient.CustomViewCallback callback = customViewCallback;
        customViewCallback = null;
        if (callback != null) {
            callback.onCustomViewHidden();
        }
        getWindow().getDecorView().setSystemUiVisibility(0x2000 | 0x10);
    }

    // ------------------------------------------------------------------
    // Downloads
    // ------------------------------------------------------------------

    private void startDownload(String url, String userAgent,
            String contentDisposition, String mimeType) {
        if (url == null
                || !(url.startsWith("http://") || url.startsWith("https://"))) {
            showToast("This kind of download isn't supported.");
            return;
        }

        try {
            String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            if (mimeType != null && mimeType.length() > 0) {
                request.setMimeType(mimeType);
            }
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) {
                request.addRequestHeader("Cookie", cookie);
            }
            if (userAgent != null) {
                request.addRequestHeader("User-Agent", userAgent);
            }
            request.setTitle(fileName);
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);

            DownloadManager manager =
                    (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);

            showToast("Downloading " + fileName);
            callJs("window.assnDownloadStarted&&window.assnDownloadStarted("
                    + quote(fileName) + "," + quote(url) + ");");
        } catch (Exception e) {
            showToast("The download could not be started.");
        }
    }

    // ------------------------------------------------------------------
    // Talking to the ASSN page
    // ------------------------------------------------------------------

    private void notifyPage(int tabId, WebView view) {
        callJs("window.assnPageInfo&&window.assnPageInfo("
                + tabId + ","
                + quote(view.getUrl()) + ","
                + quote(view.getTitle()) + ","
                + view.canGoBack() + ","
                + view.canGoForward() + ");");
    }

    private void callJs(String script) {
        uiView.evaluateJavascript(script, null);
    }

    private static String quote(String value) {
        if (value == null) {
            value = "";
        }
        return JSONObject.quote(value)
                .replace(String.valueOf((char) 0x2028), "\\u2028")
                .replace(String.valueOf((char) 0x2029), "\\u2029");
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ------------------------------------------------------------------
    // JavaScript bridge (only ever attached to the ASSN interface page)
    // ------------------------------------------------------------------

    public class Bridge {

        @JavascriptInterface
        public void navigate(final int tabId, final String url, final boolean desktop) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (url == null) {
                        return;
                    }
                    String lower = url.toLowerCase(Locale.ROOT);
                    if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
                        return;
                    }
                    boolean wasDesktop = desktopTabs.contains(tabId);
                    if (desktop) {
                        desktopTabs.add(tabId);
                    } else {
                        desktopTabs.remove(tabId);
                    }
                    WebView view = tabViews.get(tabId);
                    if (view == null) {
                        view = createTabView(tabId);
                    } else if (wasDesktop != desktop) {
                        applyUserAgent(view, desktop);
                    }
                    applyTheme(view, url);
                    view.loadUrl(url);
                }
            });
        }

        @JavascriptInterface
        public void setDesktop(final int tabId, final boolean desktop) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (desktop) {
                        desktopTabs.add(tabId);
                    } else {
                        desktopTabs.remove(tabId);
                    }
                    WebView view = tabViews.get(tabId);
                    if (view != null) {
                        applyUserAgent(view, desktop);
                        view.reload();
                    }
                }
            });
        }

        /** Takes a small picture of a tab and sends it to the tab view. */
        @JavascriptInterface
        public void captureTab(final int tabId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        WebView view = tabViews.get(tabId);
                        if (view == null || view.getWidth() <= 0 || view.getHeight() <= 0
                                || view.getVisibility() != View.VISIBLE) {
                            return;
                        }
                        float scale = 420f / view.getWidth();
                        int w = 420;
                        int h = Math.max(1, Math.round(view.getHeight() * scale));
                        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                        Canvas canvas = new Canvas(bmp);
                        canvas.scale(scale, scale);
                        view.draw(canvas);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.JPEG, 60, out);
                        bmp.recycle();
                        String data = "data:image/jpeg;base64,"
                                + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                        uiView.evaluateJavascript(
                                "window.airTabThumb&&window.airTabThumb(" + tabId + ",'" + data + "');",
                                null);
                    } catch (Throwable ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void openBackgroundSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Uri pkg = Uri.parse("package:" + getPackageName());
                    try {
                        boolean already = false;
                        if (Build.VERSION.SDK_INT >= 23) {
                            android.os.PowerManager pm =
                                    (android.os.PowerManager) getSystemService(Context.POWER_SERVICE);
                            already = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
                        }
                        String action = already
                                ? "android.settings.APPLICATION_DETAILS_SETTINGS"
                                : "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS";
                        startActivity(new Intent(action, pkg));
                    } catch (Exception first) {
                        try {
                            startActivity(new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", pkg));
                        } catch (Exception second) {
                            Toast.makeText(MainActivity.this,
                                    "Open Settings > Apps > Air > Battery", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void setAdBlock(boolean on) {
            adBlock = on;
        }

        @JavascriptInterface
        public void setBackgroundPlay(final boolean on) {
            backgroundPlay = on;
            if (on && Build.VERSION.SDK_INT >= 33) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                                != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[] {"android.permission.POST_NOTIFICATIONS"}, 77);
                        }
                    }
                });
            }
        }

        @JavascriptInterface
        public void setPrivate(final int tabId, final boolean isPrivate) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (isPrivate) {
                        privateTabs.add(tabId);
                    } else {
                        privateTabs.remove(tabId);
                    }
                    WebView view = tabViews.get(tabId);
                    if (view != null) {
                        applyCacheMode(view, isPrivate);
                        if (isPrivate) {
                            // Turning InPrivate on: forget what was cached so far.
                            view.clearCache(true);
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void clearBrowsingData(final boolean cookies, final boolean cache) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (cookies) {
                        CookieManager.getInstance().removeAllCookies(null);
                        CookieManager.getInstance().flush();
                        WebStorage.getInstance().deleteAllData();
                    }
                    if (cache) {
                        for (WebView view : tabViews.values()) {
                            view.clearCache(true);
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void setZoom(final int tabId, final int percent) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int zoom = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, percent));
                    zoomTabs.put(tabId, zoom);
                    WebView view = tabViews.get(tabId);
                    if (view != null) {
                        applyZoom(tabId, view);
                    }
                }
            });
        }

        @JavascriptInterface
        public void setMuted(final int tabId, final boolean muted) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (muted) {
                        mutedTabs.add(tabId);
                    } else {
                        mutedTabs.remove(tabId);
                    }
                    WebView view = tabViews.get(tabId);
                    if (view != null) {
                        view.evaluateJavascript(
                                "window.__assnSetMuted&&window.__assnSetMuted(" + muted + ");",
                                null);
                    }
                    sendAudio(tabId);
                }
            });
        }

        @JavascriptInterface
        public void setLayout(final int tabId, final boolean web, final boolean expanded) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    boolean tabChanged = tabId != activeTabId;
                    activeTabId = tabId;
                    webVisible = web;
                    uiExpanded = expanded;
                    if (tabChanged) {
                        setChromeHidden(false, false);
                    }
                    applyLayout();
                }
            });
        }

        @JavascriptInterface
        public void goBack(final int tabId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    WebView view = tabViews.get(tabId);
                    if (view != null && view.canGoBack()) {
                        view.goBack();
                    }
                }
            });
        }

        @JavascriptInterface
        public void goForward(final int tabId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    WebView view = tabViews.get(tabId);
                    if (view != null && view.canGoForward()) {
                        view.goForward();
                    }
                }
            });
        }

        @JavascriptInterface
        public void reload(final int tabId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    WebView view = tabViews.get(tabId);
                    if (view != null) {
                        view.reload();
                    }
                }
            });
        }

        @JavascriptInterface
        public void closeTab(final int tabId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    boolean wasPrivate = privateTabs.remove(tabId);
                    desktopTabs.remove(tabId);
                    mutedTabs.remove(tabId);
                    audibleTabs.remove(tabId);
                    zoomTabs.remove(tabId);
                    WebView view = tabViews.remove(tabId);
                    if (view != null) {
                        if (wasPrivate) {
                            wipePrivateView(view);
                        }
                        destroyView(view);
                    }
                }
            });
        }

        @JavascriptInterface
        public void closeAllTabs() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    for (Map.Entry<Integer, WebView> entry
                            : new ArrayList<Map.Entry<Integer, WebView>>(tabViews.entrySet())) {
                        if (privateTabs.contains(entry.getKey())) {
                            wipePrivateView(entry.getValue());
                        }
                        destroyView(entry.getValue());
                    }
                    tabViews.clear();
                    privateTabs.clear();
                    desktopTabs.clear();
                    mutedTabs.clear();
                    audibleTabs.clear();
                    zoomTabs.clear();
                }
            });
        }

        @JavascriptInterface
        public void download(final String url) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startDownload(url, browserUserAgent, null, null);
                }
            });
        }

        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showToast(message);
                }
            });
        }

        @JavascriptInterface
        public String getData(String key) {
            return getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(key, "");
        }

        @JavascriptInterface
        public void setData(String key, String value) {
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putString(key, value).apply();
        }
    }
}

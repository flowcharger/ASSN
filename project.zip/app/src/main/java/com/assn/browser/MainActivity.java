package com.assn.browser;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ASSN Browser.
 *
 * The interface (tab strip, address bar, menus, tab overview) is the ASSN HTML
 * page in assets/. Every tab's real website runs in its own Chromium WebView
 * placed underneath the interface's top bar.
 */
public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int STORAGE_PERMISSION_REQUEST = 1002;

    /** Height of the tab strip (50) + toolbar (58) in the HTML, in dp. */
    private static final int TOP_BAR_DP = 108;

    private static final String UI_URL = "file:///android_asset/index.html";
    private static final String UI_ASSET_PREFIX = "file:///android_asset/";
    private static final String PREFS_NAME = "assn_prefs";

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    private final Map<Integer, WebView> tabViews = new HashMap<Integer, WebView>();
    private final Set<Integer> desktopTabs = new HashSet<Integer>();

    private FrameLayout root;
    private FrameLayout contentContainer;
    private FrameLayout fullscreenContainer;
    private WebView uiView;

    private int topBarPx;
    private int activeTabId = 0;
    private boolean webVisible = false;
    private boolean uiExpanded = true;
    private String browserUserAgent;
    private String desktopUserAgent;

    private FrameLayout.LayoutParams contentParams;
    private boolean chromeHidden = false;
    private int scrollAccum = 0;
    private long lastChromeToggle = 0;

    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private ValueCallback<Uri[]> filePathCallback;

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        topBarPx = dp(TOP_BAR_DP);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#E9F5EA"));

        // Websites live here, below the HTML top bar.
        contentContainer = new FrameLayout(this);
        contentParams = new FrameLayout.LayoutParams(MATCH, MATCH);
        contentParams.topMargin = topBarPx;
        root.addView(contentContainer, contentParams);

        // The ASSN interface sits on top. It is full screen whenever it needs
        // the whole page (home, tab overview, menus) and only the top bar
        // while a website is showing.
        uiView = new WebView(this);
        uiView.setBackgroundColor(Color.TRANSPARENT);
        configureUiView();
        root.addView(uiView, new FrameLayout.LayoutParams(MATCH, MATCH));

        // Full screen video player.
        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);

        browserUserAgent = buildBrowserUserAgent();
        desktopUserAgent = buildDesktopUserAgent(browserUserAgent);

        CookieManager.getInstance().setAcceptCookie(true);

        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    STORAGE_PERMISSION_REQUEST);
        }

        uiView.loadUrl(UI_URL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        uiView.onPause();
        for (WebView view : tabViews.values()) {
            view.onPause();
        }
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        uiView.onResume();
        for (WebView view : tabViews.values()) {
            view.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        hideCustomView();
        for (WebView view : new ArrayList<WebView>(tabViews.values())) {
            destroyView(view);
        }
        tabViews.clear();
        root.removeView(uiView);
        uiView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustomView();
            return;
        }

        // Let the ASSN page close menus / overview / tool pages first.
        uiView.evaluateJavascript(
                "(window.assnHandleBack&&window.assnHandleBack())?'1':'0'",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if ("\"1\"".equals(value)) {
                            return;
                        }
                        WebView view = tabViews.get(activeTabId);
                        if (webVisible && view != null && view.canGoBack()) {
                            view.goBack();
                        } else {
                            finish();
                        }
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // ------------------------------------------------------------------
    // The ASSN interface WebView
    // ------------------------------------------------------------------

    private void configureUiView() {
        WebSettings settings = uiView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setTextZoom(100);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        uiView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        uiView.addJavascriptInterface(new Bridge(), "AssnNative");

        uiView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // The interface must never navigate away from its own page.
                return !request.getUrl().toString().startsWith(UI_ASSET_PREFIX);
            }
        });
    }

    /** Chrome-like user agent (without the "; wv" marker some sites block). */
    private String buildBrowserUserAgent() {
        String agent = uiView.getSettings().getUserAgentString();
        if (agent == null) {
            return null;
        }
        agent = agent.replace("; wv)", ")");
        agent = agent.replaceAll("Version/[0-9.]+ ", "");
        return agent;
    }

    // ------------------------------------------------------------------
    // Website tabs
    // ------------------------------------------------------------------

    private WebView createTabView(final int tabId) {
        WebView view = new WebView(this);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        applyUserAgent(view, desktopTabs.contains(tabId));

        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true);

        // Scrolling down hides the ASSN bars, scrolling up brings them back.
        view.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY,
                    int oldScrollX, int oldScrollY) {
                onTabScrolled(tabId, scrollY, scrollY - oldScrollY);
            }
        });

        view.setWebViewClient(new TabClient(tabId));
        view.setWebChromeClient(new TabChrome(tabId));
        view.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                    String contentDisposition, String mimeType, long contentLength) {
                startDownload(url, userAgent, contentDisposition, mimeType);
            }
        });

        view.setVisibility(View.GONE);
        tabViews.put(tabId, view);
        contentContainer.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH));
        return view;
    }

    private void destroyView(WebView view) {
        view.stopLoading();
        view.setWebViewClient(new WebViewClient());
        view.setWebChromeClient(null);
        contentContainer.removeView(view);
        view.destroy();
    }

    private void applyUserAgent(WebView view, boolean desktop) {
        String agent = desktop ? desktopUserAgent : browserUserAgent;
        if (agent != null) {
            view.getSettings().setUserAgentString(agent);
        }
    }

    /** Same Chrome version as the phone agent, but pretending to be a desktop. */
    private static String buildDesktopUserAgent(String mobileAgent) {
        String chrome = "Chrome/120.0.0.0";
        if (mobileAgent != null) {
            Matcher matcher = Pattern.compile("Chrome/[0-9.]+").matcher(mobileAgent);
            if (matcher.find()) {
                chrome = matcher.group();
            }
        }
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                + chrome + " Safari/537.36";
    }

    private void onTabScrolled(int tabId, int scrollY, int dy) {
        if (tabId != activeTabId || !webVisible || uiExpanded) {
            return;
        }
        // Ignore the scroll jitter caused by the bars sliding away or back.
        if (SystemClock.uptimeMillis() - lastChromeToggle < 350) {
            scrollAccum = 0;
            return;
        }
        if (scrollY <= 0) {
            setChromeHidden(false, true);
            return;
        }
        if ((dy > 0) != (scrollAccum > 0)) {
            scrollAccum = 0;
        }
        scrollAccum += dy;
        if (scrollAccum > dp(24)) {
            setChromeHidden(true, true);
        } else if (scrollAccum < -dp(12)) {
            setChromeHidden(false, true);
        }
    }

    /**
     * Slides the tab strip + toolbar off the top (and the page up into the
     * space), or back again. The page is made taller before it slides so it
     * never shows a gap at the bottom.
     */
    private void setChromeHidden(boolean hide, boolean animate) {
        if (hide == chromeHidden) {
            return;
        }
        if (hide && (!webVisible || uiExpanded)) {
            return;
        }
        chromeHidden = hide;
        scrollAccum = 0;
        lastChromeToggle = SystemClock.uptimeMillis();

        float target = hide ? -topBarPx : 0f;
        long duration = animate ? 180 : 0;

        if (hide) {
            contentParams.bottomMargin = -topBarPx;
            contentContainer.setLayoutParams(contentParams);
        }

        uiView.animate().translationY(target).setDuration(duration).start();

        ViewPropertyAnimator pageAnimator =
                contentContainer.animate().translationY(target).setDuration(duration);
        if (!hide) {
            pageAnimator.withEndAction(new Runnable() {
                @Override
                public void run() {
                    if (!chromeHidden) {
                        contentParams.bottomMargin = 0;
                        contentContainer.setLayoutParams(contentParams);
                    }
                }
            });
        }
        pageAnimator.start();
    }

    private void applyLayout() {
        if (!webVisible || uiExpanded) {
            setChromeHidden(false, false);
        }
        for (Map.Entry<Integer, WebView> entry : tabViews.entrySet()) {
            boolean show = webVisible && entry.getKey().intValue() == activeTabId;
            entry.getValue().setVisibility(show ? View.VISIBLE : View.GONE);
        }

        // A website is showing: only the top bar belongs to the interface,
        // unless a menu needs the full screen.
        int wantedHeight = uiExpanded ? MATCH : topBarPx;
        ViewGroup.LayoutParams params = uiView.getLayoutParams();
        if (params.height != wantedHeight) {
            params.height = wantedHeight;
            uiView.setLayoutParams(params);
        }
    }

    private boolean handleUrl(String url) {
        if (url == null) {
            return true;
        }
        String lower = url.toLowerCase(Locale.ROOT);

        if (lower.startsWith("http://") || lower.startsWith("https://")
                || lower.startsWith("about:") || lower.startsWith("javascript:")
                || lower.startsWith("data:") || lower.startsWith("blob:")) {
            return false;
        }

        if (lower.startsWith("file:") || lower.startsWith("content:")) {
            return true;
        }

        // mailto:, tel:, intent:, market: ... hand over to other apps.
        try {
            Intent intent;
            if (lower.startsWith("intent:")) {
                intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setComponent(null);
                intent.setSelector(null);
            } else {
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            }
            startActivity(intent);
        } catch (Exception e) {
            showToast("No app can open this link.");
        }
        return true;
    }

    private class TabClient extends WebViewClient {
        private final int tabId;

        TabClient(int tabId) {
            this.tabId = tabId;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleUrl(request.getUrl().toString());
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            if (tabId == activeTabId) {
                setChromeHidden(false, true);
            }
            notifyPage(tabId, view);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            notifyPage(tabId, view);
        }

        @Override
        public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
            super.doUpdateVisitedHistory(view, url, isReload);
            notifyPage(tabId, view);
        }
    }

    private class TabChrome extends WebChromeClient {
        private final int tabId;

        TabChrome(int tabId) {
            this.tabId = tabId;
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            notifyPage(tabId, view);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            showCustomView(view, callback);
        }

        @Override
        public void onHideCustomView() {
            hideCustomView();
        }

        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                FileChooserParams params) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = callback;
            try {
                startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST);
            } catch (Exception e) {
                filePathCallback = null;
                return false;
            }
            return true;
        }
    }

    // ------------------------------------------------------------------
    // Full screen video
    // ------------------------------------------------------------------

    private void showCustomView(View view, WebChromeClient.CustomViewCallback callback) {
        if (customView != null) {
            callback.onCustomViewHidden();
            return;
        }
        customView = view;
        customViewCallback = callback;
        fullscreenContainer.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH));
        fullscreenContainer.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void hideCustomView() {
        if (customView == null) {
            return;
        }
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;

        WebChromeClient.CustomViewCallback callback = customViewCallback;
        customViewCallback = null;
        if (callback != null) {
            callback.onCustomViewHidden();
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ------------------------------------------------------------------
    // Downloads
    // ------------------------------------------------------------------

    private void startDownload(String url, String userAgent,
            String contentDisposition, String mimeType) {
        if (url == null
                || !(url.startsWith("http://") || url.startsWith("https://"))) {
            showToast("This kind of download isn't supported.");
            return;
        }

        try {
            String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            if (mimeType != null && mimeType.length() > 0) {
                request.setMimeType(mimeType);
            }
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) {
                request.addRequestHeader("Cookie", cookie);
            }
            if (userAgent != null) {
                request.addRequestHeader("User-Agent", userAgent);
            }
            request.setTitle(fileName);
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);

            DownloadManager manager =
                    (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);

            showToast("Downloading " + fileName);
            callJs("window.assnDownloadStarted&&window.assnDownloadStarted("
                    + quote(fileName) + "," + quote(url) + ");");
        } catch (Exception e) {
            showToast("The download could not be started.");
        }
    }

    // ------------------------------------------------------------------
    // Talking to the ASSN page
    // ------------------------------------------------------------------

    private void notifyPage(int tabId, WebView view) {
        callJs("window.assnPageInfo&&window.assnPageInfo("
                + tabId + ","
                + quote(view.getUrl()) + ","
                + quote(view.getTitle()) + ","
                + view.canGoBack() + ","
                + view.canGoForward() + ");");
    }

    private void callJs(String script) {
        uiView.evaluateJavascript(script, null);
    }

    private static String quote(String value) {
        if (value == null) {
            value = "";
        }
        return JSONObject.quote(value)
                .replace(String.valueOf((char) 0x2028), "\\u2028")
                .replace(String.valueOf((char) 0x2029), "\\u2029");
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ------------------------------------------------------------------
    // JavaScript bridge (only ever attached to the ASSN interface page)
    // ------------------------------------------------------------------

    public class Bridge {

        @JavascriptInterface
        public void navigate(final int tabId, final String url, final boolean desktop) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (url == null) {
                        return;
                    }
                    String lower = url.toLowerCase(Locale.ROOT);
                    if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
                        return;
                    }
                    boolean wasDesktop = desktopTabs.contains(tabId);
                    if (desktop) {
                        desktopTabs.add(tabId);
                    } else {
                        desktopTabs.remove(tabId);
                    }
                    WebView view = tabViews.get(tabId);
                    if (view == null) {
                        view = createTabView(tabId);
                    } else if (wasDesktop != desktop) {
                        applyUserAgent(view, desktop);
                    }
                    view.loadUrl(url);
                }
            });
        }

        @JavascriptInterface
        public void setDesktop(final int tabId, final boolean desktop) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (desktop) {
                        desktopTabs.add(tabId);
                    } else {
                        desktopTabs.remove(tabId);
                    }
                    WebView view = tabViews.get(tabId);
                    if (view != null) {
                        applyUserAgent(view, desktop);
                        view.reload();
                    }
                }
            });
        }

        @JavascriptInterface
        public void setLayout(final int tabId, final boolean web, final boolean expanded) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    boolean tabChanged = tabId != activeTabId;
                    activeTabId = tabId;
                    webVisible = web;
                    uiExpanded = expanded;
                    if (tabChanged) {
                        setChromeHidden(false, false);
                    }
                    applyLayout();
                }
            });
        }

        @JavascriptInterface
        public void goBack(final int tabId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    WebView view = tabViews.get(tabId);
                    if (view != null && view.canGoBack()) {
                        view.goBack();
                    }
                }
            });
        }

        @JavascriptInterface
        public void goForward(final int tabId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    WebView view = tabViews.get(tabId);
                    if (view != null && view.canGoForward()) {
                        view.goForward();
                    }
                }
            });
        }

        @JavascriptInterface
        public void reload(final int tabId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    WebView view = tabViews.get(tabId);
                    if (view != null) {
                        view.reload();
                    }
                }
            });
        }

        @JavascriptInterface
        public void closeTab(final int tabId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    desktopTabs.remove(tabId);
                    WebView view = tabViews.remove(tabId);
                    if (view != null) {
                        destroyView(view);
                    }
                }
            });
        }

        @JavascriptInterface
        public void closeAllTabs() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    for (WebView view : new ArrayList<WebView>(tabViews.values())) {
                        destroyView(view);
                    }
                    tabViews.clear();
                    desktopTabs.clear();
                }
            });
        }

        @JavascriptInterface
        public void download(final String url) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startDownload(url, browserUserAgent, null, null);
                }
            });
        }

        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showToast(message);
                }
            });
        }

        @JavascriptInterface
        public String getData(String key) {
            return getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(key, "");
        }

        @JavascriptInterface
        public void setData(String key, String value) {
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putString(key, value).apply();
        }
    }
}
